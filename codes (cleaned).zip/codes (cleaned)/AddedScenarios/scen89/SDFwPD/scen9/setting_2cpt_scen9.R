# Aug 12 2021
# 2-cpt models
# scen 9    

doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas9.5pl= c(0.001, 0.483, 1.688, -0.814, 1.456) 

paramLst_pkpop_sc9= list(V= 28, sd_lV= 0.32, 
                         k= 0.82, sd_lk= 0.32, 
                         a= 0.14, a2= 0.14)

linkParam= c(1.06, 1.319)

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain= 3

targetProb= 0.3
ksi= 0.9
T0= 1/24

to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma","lambda", "a", "a2")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())


scenNum= 9
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStan1/scen9/traces/"
