# Aug 12 2021
# 2-cpt models
# scen 4

doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
#betas4.5pl= c(0, 0.632, 9, -0.796, 1.267)

# settings for scen 4
#paramLst_pkpop_sc4= list(V= 32, sd_lV= 0.3, 
#                         alpha= 12, sd_lalpha= 0.3,
#                         beta= 0.2, sd_lbeta= 0.29, 
#                         k21= 7.5, sd_lk21= 0.29, 
#                         a= 0.2, a2= 0.1)

betas4.5pl= c(0, 0.632, 9, -0.796, 1.267)

paramLst_pkpop_sc4= list(V= 32, sd_lV= 0.25, 
                         alpha= 12, sd_lalpha= 0.23,
                         beta= 0.2, sd_lbeta= 0.21, 
                         k21= 7.5, sd_lk21= 0.25, 
                         a= 0.14, a2= 0.1)


x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain=3

targetProb= 0.3
ksi= 0.9
T0= 1/24


# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(32,12,0.2,7.5)), 
                 betas= betas4.5pl, 
                 inte_range= c(0,21))
})
print(true.pi)


scenNum= 4
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanwoPD/scen4/traces/"

to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma", "a")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
