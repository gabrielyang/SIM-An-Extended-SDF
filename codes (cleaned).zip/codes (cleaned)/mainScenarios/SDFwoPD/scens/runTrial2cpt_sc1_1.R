# Jan 10 2020
# run simulations for scenario 1

# load relevant scripts
library(Rcpp)
library(rstan)

source("2cpt_woPD_prep.R")
source("scen1_settings.R")

sourceCpp("piMatwoPD0417.cpp")
mod= stan_model("sdfwopd0417.stan")

set.seed(1)


for(nSim in 1: 20) {
    print(nSim)

    oo2= run_1_trial_2cpt(cohortSize=3, 
                          maxNum= 30,
                          paramLst_pkpop= paramLst_pkpop_sc1, 
                          pd_param_5pl= betas1,
                          x_timePoints= x_timePoints, 
                          z_timePoints= z_timePoints,
                          inte_range= inte_range, 
                          T0= T0, doseVec= doseVec,
                          S= S, nBurnin= nBurnin, thin= thin, 
                          nchain= nchain,
                          targetProb= targetProb, ksi= ksi, 
                          nSim= nSim, scen= scenNum,
                          path= path1, to_plot= to_plot)
    
    saveRDS(oo2, file= paste("scen",scenNum, "_res_", nSim,".rds", 
                             sep= ''))
}

