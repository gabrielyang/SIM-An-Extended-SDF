# Mar 17 2023

# load relevant scripts
source("prep_CRM.R")

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)
targetProb= 0.3
ksi= 0.9
T0= 1/24

linkParam8= c(0.682, 1.303)
linkParam9= c(1.06, 1.319)

doseVec= c(10,30,60,90,150)
doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas8.5pl= c(0.001, 0.419, 1.691, -0.793, 1.462)
betas9.5pl= c(0.001, 0.483, 1.688, -0.814, 1.456) 



# settings for scen 8
paramLst_pkpop_sc8= list(V= 29.5, sd_lV= 0.30, 
                         k21= 0.8, sd_lk21= 0.30, 
                         a= 0.14, a2= 0.14)

# 2 prior skeletons for CRM
p0.1 = dfcrm::getprior(halfwidth= 0.05, target= 0.3, 
                       nu=3, nlevel= 5, model="empiric") 
print(p0.1)


p0.2 = dfcrm::getprior(halfwidth= 0.075, target= 0.3, 
                     nu=3, nlevel= 5, model="empiric") 
print(p0.2)


# scen 1
print("scen 1")
# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.1co.5pl2(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(29.5,0.8)), 
                 betas= betas8.5pl, linkParam= linkParam8, 
                 inte_range= c(0,21))
})

true.pi


# for CRM1
print("CRM1")

set.seed(101)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc8, 
                pd_param_5pl= betas8.5pl, linkParam= linkParam8,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen8","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(107)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc8, 
                pd_param_5pl= betas8.5pl, linkParam=linkParam8,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen8","_res_CRM2",".rds", sep= ''))


# scen 9
print("scen 9")
true.pi= sapply(1:5, function(x) {
    link.1co.5pl2(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(28, 0.82)), 
                 betas= betas9.5pl, linkParam= linkParam9, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc9= list(V= 28, sd_lV= 0.32, 
                         k21= 0.82, sd_lk21= 0.32, 
                         a= 0.14, a2= 0.14)


# for CRM1
print("CRM1")

set.seed(10)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc9, 
                pd_param_5pl= betas9.5pl, linkParam= linkParam9,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen9","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(11)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc9, 
                pd_param_5pl= betas9.5pl, linkParam= linkParam9,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen9","_res_CRM2",".rds", sep= ''))



