# Feb 14 2023

###########################################
# estimation accuracy (MAE and RMSE of tried doses)
###########################################
# for SDF-wPD 
getToxProb= function(lst, numDoseLevel= 5) {
  N= length(lst)
  MTDidx_vec= NULL
  toxEstMat= matrix(NA, nrow= N, ncol= numDoseLevel)
  triedDoseMat= matrix(NA, nrow= N, ncol= numDoseLevel)
  
  for(i in 1: N) {
    MTDidx_vec[i]= lst[[i]]$MTD
    if(MTDidx_vec[i] != 0) {
      toxEstMat[i, ]= lst[[i]]$mat1[nrow(lst[[i]]$mat1),c(4:8)]
      triedDoseMat[i,]=
        lst[[i]]$triedDose_mat[nrow(lst[[i]]$triedDose_mat),]
    }
  }
  idx= complete.cases(toxEstMat)
  toxEstMat= toxEstMat[idx, ]
  triedDoseMat= triedDoseMat[idx, ]
  return(list(toxEstMat= toxEstMat, triedDoseMat= triedDoseMat))
}

# calc. MAE and RMSE of tried doses
calcMetric.1= function(toxProbMat, triedDoseMat, truth) {
  nDose= length(truth)
  S= nrow(toxProbMat)
  
  MAE.raw= sapply(1:nDose, function(k) {
    mean(abs(na.omit(toxProbMat[,k]*triedDoseMat[,k])- truth[k]) )
  })
  
  MSE.raw= sapply(1:nDose, function(k) {
    mean((na.omit(toxProbMat[,k]*triedDoseMat[,k])- truth[k])^2)
  })
  wt= colSums(triedDoseMat, na.rm= T)
  res= c(sum(MAE.raw* wt, na.rm= T)/sum(wt,na.rm= T), 
         sqrt(sum(MSE.raw* wt, na.rm= T)/sum(wt, na.rm= T)) )
  # MAE and RMSE
  return(res)
}

# the truths
truth.sc1= c(0.01, 0.06, 0.18, 0.31, 0.51)
truth.sc2= c(0.16, 0.29, 0.40, 0.48, 0.59)
truth.sc3= c(0.05, 0.10, 0.16, 0.21, 0.29)
truth.sc4= c(0.07, 0.18, 0.30, 0.40, 0.54)

# scen1
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen1")

idx= c(1:1000)
length(idx)

scen= 1
count= 0

lst1= NULL

for(i in idx) {
  count= count+ 1
  lst1[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

#save(lst1, file= "aim2_sdf_res_sc1.RData")
#load(file= "aim2_sdf_res_sc1.RData")

toxProbMat1= getToxProb(lst= lst1, numDoseLevel= 5)$toxEstMat
triedDoseMat1= getToxProb(lst= lst1, numDoseLevel= 5)$triedDoseMat
triedDoseMat1[triedDoseMat1== 0]=NA


# scen1, SDF 
calcMetric.1(toxProbMat= toxProbMat1, 
             triedDoseMat= triedDoseMat1, 
             truth= truth.sc1)


# scen2
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen2")

idx= c(1:1000)
length(idx)

scen= 2
count= 0

lst2= NULL

for(i in idx) {
  count= count+ 1
  lst2[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

#save(lst2, file= "aim2_sdf_res_sc2.RData")
#load(file= "aim2_sdf_res_sc2.RData")

# scen2, SDF 
toxProbMat2= getToxProb(lst= lst2, numDoseLevel= 5)$toxEstMat
triedDoseMat2= getToxProb(lst= lst2, numDoseLevel= 5)$triedDoseMat
triedDoseMat2[triedDoseMat2== 0]=NA

calcMetric.1(toxProbMat= toxProbMat2, 
             triedDoseMat= triedDoseMat2, 
             truth= truth.sc2)


# scen3
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen3")


idx= c(1:1000)
length(idx)

scen= 3
count= 0

lst3= NULL

for(i in idx) {
  count= count+ 1
  lst3[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

#save(lst3, file= "aim2_sdf_res_sc3.RData")
#load(file= "aim2_sdf_res_sc3.RData")

# scen3, SDF 
toxProbMat3= getToxProb(lst= lst3, numDoseLevel= 5)$toxEstMat
triedDoseMat3= getToxProb(lst= lst3, numDoseLevel= 5)$triedDoseMat
triedDoseMat3[triedDoseMat3== 0]=NA

calcMetric.1(toxProbMat= toxProbMat3, 
             triedDoseMat= triedDoseMat3, 
             truth= truth.sc3)


# scen4
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen4")

idx= c(1:1000)
length(idx)

scen= 4
count= 0

lst4= NULL

for(i in idx) {
  count= count+ 1
  lst4[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

#save(lst4, file= "aim2_sdf_res_sc4.RData")
#load(file= "aim2_sdf_res_sc4.RData")

# scen4, SDF 
toxProbMat4= getToxProb(lst= lst4, numDoseLevel= 5)$toxEstMat
triedDoseMat4= getToxProb(lst= lst4, numDoseLevel= 5)$triedDoseMat
triedDoseMat4[triedDoseMat4== 0]=NA

calcMetric.1(toxProbMat= toxProbMat4, 
             triedDoseMat= triedDoseMat4, 
             truth= truth.sc4)



#####################################
# for CRM
#####################################
# a function to get triedDoseMat
cleanCRMLst= function(CRMResLst, ndose, chtSize) {
    #S= num of sims 
    S= nrow(CRMResLst$toxProbMat)
    triedDoseMat= matrix(NA, nrow= S, ncol= ndose)
    
    for(s in 1:S) {
      triedDoseMat[s,]= ifelse(CRMResLst$numTreated_mat[s,]>= chtSize, 
                               1, 0)
    }
    
    return(list(toxProbMat= CRMResLst$toxProbMat,
                triedDoseMat= triedDoseMat))
}

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/CRM")
# numTreated_mat, toxProbMat
#######
# CRM1
#######

# scen1
crm1.sc1= readRDS(file= "scen1_res_CRM1.rds")
resCRM1.sc1= cleanCRMLst(CRMResLst= crm1.sc1, ndose=5, chtSize=3) 

toxProbMat.crm1.sc1= resCRM1.sc1$toxProbMat
triedDoseMat.crm1.sc1= resCRM1.sc1$triedDoseMat
triedDoseMat.crm1.sc1[triedDoseMat.crm1.sc1== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm1.sc1, 
             triedDoseMat= triedDoseMat.crm1.sc1, 
             truth= truth.sc1)

# scen2
crm1.sc2= readRDS(file= "scen2_res_CRM1.rds")
resCRM1.sc2= cleanCRMLst(CRMResLst= crm1.sc2, ndose=5, chtSize=3) 

toxProbMat.crm1.sc2= resCRM1.sc2$toxProbMat
triedDoseMat.crm1.sc2= resCRM1.sc2$triedDoseMat
triedDoseMat.crm1.sc2[triedDoseMat.crm1.sc2== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm1.sc2, 
             triedDoseMat= triedDoseMat.crm1.sc2, 
             truth= truth.sc2)


# # scen3
crm1.sc3= readRDS(file= "scen3_res_CRM1.rds")
resCRM1.sc3= cleanCRMLst(CRMResLst= crm1.sc3, ndose=5, chtSize=3) 

toxProbMat.crm1.sc3= resCRM1.sc3$toxProbMat
triedDoseMat.crm1.sc3= resCRM1.sc3$triedDoseMat
triedDoseMat.crm1.sc3[triedDoseMat.crm1.sc3== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm1.sc3, 
             triedDoseMat= triedDoseMat.crm1.sc3, 
             truth= truth.sc3)


# # scen4
crm1.sc4= readRDS(file= "scen4_res_CRM1.rds")
resCRM1.sc4= cleanCRMLst(CRMResLst= crm1.sc4, ndose=5, chtSize=3) 

toxProbMat.crm1.sc4= resCRM1.sc4$toxProbMat
triedDoseMat.crm1.sc4= resCRM1.sc4$triedDoseMat
triedDoseMat.crm1.sc4[triedDoseMat.crm1.sc4== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm1.sc4, 
             triedDoseMat= triedDoseMat.crm1.sc4, 
             truth= truth.sc4)

#######
# CRM2
#######
# scen1
crm2.sc1= readRDS(file= "scen1_res_CRM2.rds")
resCRM2.sc1= cleanCRMLst(CRMResLst= crm2.sc1, ndose=5, chtSize=3) 

toxProbMat.crm2.sc1= resCRM2.sc1$toxProbMat
triedDoseMat.crm2.sc1= resCRM2.sc1$triedDoseMat
triedDoseMat.crm2.sc1[triedDoseMat.crm2.sc1== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm2.sc1, 
             triedDoseMat= triedDoseMat.crm2.sc1, 
             truth= truth.sc1)

# scen2
crm2.sc2= readRDS(file= "scen2_res_CRM2.rds")
resCRM2.sc2= cleanCRMLst(CRMResLst= crm2.sc2, ndose=5, chtSize=3) 

toxProbMat.crm2.sc2= resCRM2.sc2$toxProbMat
triedDoseMat.crm2.sc2= resCRM2.sc2$triedDoseMat
triedDoseMat.crm2.sc2[triedDoseMat.crm2.sc2== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm2.sc2, 
             triedDoseMat= triedDoseMat.crm2.sc2, 
             truth= truth.sc2)


# # scen3
crm2.sc3= readRDS(file= "scen3_res_CRM2.rds")
resCRM2.sc3= cleanCRMLst(CRMResLst= crm2.sc3, ndose=5, chtSize=3) 

toxProbMat.crm2.sc3= resCRM2.sc3$toxProbMat
triedDoseMat.crm2.sc3= resCRM2.sc3$triedDoseMat
triedDoseMat.crm2.sc3[triedDoseMat.crm2.sc3== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm2.sc3, 
             triedDoseMat= triedDoseMat.crm2.sc3, 
             truth= truth.sc3)


# # scen4
crm2.sc4= readRDS(file= "scen4_res_CRM2.rds")
resCRM2.sc4= cleanCRMLst(CRMResLst= crm2.sc4, ndose=5, chtSize=3) 

toxProbMat.crm2.sc4= resCRM2.sc4$toxProbMat
triedDoseMat.crm2.sc4= resCRM2.sc4$triedDoseMat
triedDoseMat.crm2.sc4[triedDoseMat.crm2.sc4== 0]=NA

calcMetric.1(toxProbMat= toxProbMat.crm2.sc4, 
             triedDoseMat= triedDoseMat.crm2.sc4, 
             truth= truth.sc4)