# May 23 2022
# script for making box plots (posterior mean of p_i) for 2-cpt models
# comparing 2cpt-SMDF and CRMs

getToxProb= function(lst, numDoseLevel= 5) {
    N= length(lst)
    MTDidx_vec= NULL
    toxEstMat= matrix(NA, nrow= N, ncol= numDoseLevel)
    
    for(i in 1: N) {
        MTDidx_vec[i]= lst[[i]]$MTD
        if(MTDidx_vec[i] != 0) {
            toxEstMat[i, ]= lst[[i]]$mat1[nrow(lst[[i]]$mat1),c(4:8)]
        }
    }
    return(toxEstMat)
}

library(ggplot2)
library(reshape2)
library(data.table)


truth.sc6= c(0.07,0.11,0.21,0.31,0.46)
truth.sc7= c(0.07, 0.16, 0.30, 0.43, 0.58)

truth.sc8= c(0.07,0.18,0.30,0.38,0.47)
truth.sc9= c(0.11, 0.27, 0.42, 0.50, 0.60)


# scen 6
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen6")

idx= c(1:1000)

length(idx)

scen= 6
count= 0

lst6= NULL
for(i in idx) {
    count= count+ 1
    lst6[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat6= getToxProb(lst= lst6, numDoseLevel= 5)
toxProbMat6.CRM1= readRDS(file= "scen6_res_CRM1.rds")$toxProbMat
toxProbMat6.CRM2= readRDS(file= "scen6_res_CRM2.rds")$toxProbMat


setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_4/scen6")
count= 0
lst6.wo= NULL

for(i in idx) {
  count= count+ 1
  lst6.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat6.wo= getToxProb(lst= lst6.wo, numDoseLevel= 5)

toxProbMat6= toxProbMat6[complete.cases(toxProbMat6),]
toxProbMat6.wo= toxProbMat6.wo[complete.cases(toxProbMat6.wo),]

plot_sc6_smdf = reshape2::melt(toxProbMat6)
names(plot_sc6_smdf)= c("sampNum", "dose", "toxProb")
plot_sc6_smdf$design= rep("SDF-wPD", nrow(plot_sc6_smdf))
plot_sc6_smdf$dose= as.factor(plot_sc6_smdf$dose)

plot_sc6_crm1 = reshape2::melt(toxProbMat6.CRM1)
names(plot_sc6_crm1)= c("sampNum", "dose", "toxProb")
plot_sc6_crm1$design= rep("CRM1", nrow(plot_sc6_crm1))
plot_sc6_crm1$dose= as.factor(plot_sc6_crm1$dose)

plot_sc6_crm2 = reshape2::melt(toxProbMat6.CRM2)
names(plot_sc6_crm2)= c("sampNum", "dose", "toxProb")
plot_sc6_crm2$design= rep("CRM2", nrow(plot_sc6_crm2))
plot_sc6_crm2$dose= as.factor(plot_sc6_crm2$dose)


plot_sc6_smdfwo = reshape2::melt(toxProbMat6.wo)
names(plot_sc6_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc6_smdfwo$design= rep("SDF-woPD", nrow(plot_sc6_smdfwo))
plot_sc6_smdfwo$dose= as.factor(plot_sc6_smdfwo$dose)

plot_sc6_comb= rbind(plot_sc6_smdf, plot_sc6_crm1, plot_sc6_crm2,
                     plot_sc6_smdfwo)
plot_sc6_comb$design= as.factor(plot_sc6_comb$design)

true_sc6_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc6)

d.sc6= data.table(x= true_sc6_df$dose, y=true_sc6_df$toxProb)


p6 <- ggplot() + 
    geom_boxplot(data=plot_sc6_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 6",
         x="dose level", y = "DLT prob.")+
    geom_line(data= true_sc6_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc6, aes(x= x, y= y),
               shape= c(2,2,2,17,2), size= 3)
p6

# scen 7
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen7")

idx= c(1:1000)

scen= 7
count= 0

lst7= NULL
for(i in idx) {
    count= count+ 1
    lst7[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat7.CRM1= readRDS(file= "scen7_res_CRM1.rds")$toxProbMat
toxProbMat7.CRM1= toxProbMat7.CRM1[complete.cases(toxProbMat7.CRM1), ]

toxProbMat7.CRM2= readRDS(file= "scen7_res_CRM2.rds")$toxProbMat
toxProbMat7.CRM2= toxProbMat7.CRM2[complete.cases(toxProbMat7.CRM2), ]

toxProbMat7= getToxProb(lst= lst7, numDoseLevel= 5)
toxProbMat7= toxProbMat7[complete.cases(toxProbMat7), ]

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_4/scen7")
count= 0
lst7.wo= NULL

for(i in idx) {
  count= count+ 1
  lst7.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat7.wo= getToxProb(lst= lst7.wo, numDoseLevel= 5)
toxProbMat7.wo= toxProbMat7.wo[complete.cases(toxProbMat7.wo), ]


plot_sc7_smdf = reshape2::melt(toxProbMat7)
names(plot_sc7_smdf)= c("sampNum", "dose", "toxProb")
plot_sc7_smdf$design= rep("SDF-wPD", nrow(plot_sc7_smdf))
plot_sc7_smdf$dose= as.factor(plot_sc7_smdf$dose)

plot_sc7_crm1 = reshape2::melt(toxProbMat7.CRM1)
names(plot_sc7_crm1)= c("sampNum", "dose", "toxProb")
plot_sc7_crm1$design= rep("CRM1", nrow(plot_sc7_crm1))
plot_sc7_crm1$dose= as.factor(plot_sc7_crm1$dose)

plot_sc7_crm2 = reshape2::melt(toxProbMat7.CRM2)
names(plot_sc7_crm2)= c("sampNum", "dose", "toxProb")
plot_sc7_crm2$design= rep("CRM2", nrow(plot_sc7_crm2))
plot_sc7_crm2$dose= as.factor(plot_sc7_crm2$dose)


plot_sc7_smdfwo = reshape2::melt(toxProbMat7.wo)
names(plot_sc7_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc7_smdfwo$design= rep("SDF-woPD", nrow(plot_sc7_smdfwo))
plot_sc7_smdfwo$dose= as.factor(plot_sc7_smdfwo$dose)

plot_sc7_comb= rbind(plot_sc7_smdf, plot_sc7_crm1, plot_sc7_crm2,
                     plot_sc7_smdfwo)
plot_sc7_comb$design= as.factor(plot_sc7_comb$design)

true_sc7_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc7)
d.sc7= data.table(x= true_sc7_df$dose, y=true_sc7_df$toxProb)


p7 <- ggplot() + 
    geom_boxplot(data= plot_sc7_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 7",
         x="dose level", y = "DLT prob.")+ 
    geom_line(data= true_sc7_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc7, aes(x= x, y= y),
               shape= c(2,2,17,2,2), size= 3)
p7


# scen 8
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen8")

idx= c(1:1000)
length(idx)

scen= 8
count= 0

lst8= NULL
for(i in idx) {
    count= count+ 1
    lst8[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat8= getToxProb(lst= lst8, numDoseLevel= 5)
toxProbMat8= toxProbMat8[complete.cases(toxProbMat8), ]

toxProbMat8.CRM1= readRDS(file= "scen8_res_CRM1.rds")$toxProbMat
toxProbMat8.CRM1= toxProbMat8.CRM1[complete.cases(toxProbMat8.CRM1), ]

toxProbMat8.CRM2= readRDS(file= "scen8_res_CRM2.rds")$toxProbMat
toxProbMat8.CRM2= toxProbMat8.CRM2[complete.cases(toxProbMat8.CRM2), ]

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_4/scen8")

idx= c(1:1000)
length(idx)

scen= 8
count= 0

lst8.wo= NULL
for(i in idx) {
  count= count+ 1
  lst8.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat8.wo= getToxProb(lst= lst8.wo, numDoseLevel= 5)
toxProbMat8.wo= toxProbMat8.wo[complete.cases(toxProbMat8.wo), ]


plot_sc8_smdf = reshape2::melt(toxProbMat8)
names(plot_sc8_smdf)= c("sampNum", "dose", "toxProb")
plot_sc8_smdf$design= rep("SDF-wPD", nrow(plot_sc8_smdf))
plot_sc8_smdf$dose= as.factor(plot_sc8_smdf$dose)

plot_sc8_crm1 = reshape2::melt(toxProbMat8.CRM1)
names(plot_sc8_crm1)= c("sampNum", "dose", "toxProb")
plot_sc8_crm1$design= rep("CRM1", nrow(plot_sc8_crm1))
plot_sc8_crm1$dose= as.factor(plot_sc8_crm1$dose)

plot_sc8_crm2 = reshape2::melt(toxProbMat8.CRM2)
names(plot_sc8_crm2)= c("sampNum", "dose", "toxProb")
plot_sc8_crm2$design= rep("CRM2", nrow(plot_sc8_crm2))
plot_sc8_crm2$dose= as.factor(plot_sc8_crm2$dose)


plot_sc8_smdfwo = reshape2::melt(toxProbMat8.wo)
names(plot_sc8_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc8_smdfwo$design= rep("SDF-woPD", nrow(plot_sc8_smdfwo))
plot_sc8_smdfwo$dose= as.factor(plot_sc8_smdfwo$dose)

plot_sc8_comb= rbind(plot_sc8_smdf, plot_sc8_crm1, plot_sc8_crm2,
                     plot_sc8_smdfwo)
plot_sc8_comb$design= as.factor(plot_sc8_comb$design)

true_sc8_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc8)
d.sc8= data.table(x= true_sc8_df$dose, y=true_sc8_df$toxProb)


p8 <- ggplot() + 
    geom_boxplot(data= plot_sc8_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 8",
         x="dose level", y = "DLT prob.")+ 
    geom_line(data= true_sc8_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc8, aes(x= x, y= y),
               shape= c(2,2,17,2,2), size= 3)
p8


# correct PK model

# scen 9
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen9")

idx= c(1:1000)
length(idx)

scen= 9
count= 0

lst9= NULL
for(i in idx) {
  count= count+ 1
  lst9[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat9= getToxProb(lst= lst9, numDoseLevel= 5)
toxProbMat9= toxProbMat9[complete.cases(toxProbMat9), ]

toxProbMat9.CRM1= readRDS(file= "scen9_res_CRM1.rds")$toxProbMat
toxProbMat9.CRM1= toxProbMat9.CRM1[complete.cases(toxProbMat9.CRM1), ]

toxProbMat9.CRM2= readRDS(file= "scen9_res_CRM2.rds")$toxProbMat
toxProbMat9.CRM2= toxProbMat9.CRM2[complete.cases(toxProbMat9.CRM2), ]

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_4/scen9")

idx= c(1:1000)
length(idx)

scen= 9
count= 0

lst9.wo= NULL
for(i in idx) {
  count= count+ 1
  lst9.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat9.wo= getToxProb(lst= lst9.wo, numDoseLevel= 5)
toxProbMat9.wo= toxProbMat9.wo[complete.cases(toxProbMat9.wo), ]

plot_sc9_smdf = reshape2::melt(toxProbMat9)
names(plot_sc9_smdf)= c("sampNum", "dose", "toxProb")
plot_sc9_smdf$design= rep("SDF-wPD", nrow(plot_sc9_smdf))
plot_sc9_smdf$dose= as.factor(plot_sc9_smdf$dose)

plot_sc9_crm1 = reshape2::melt(toxProbMat9.CRM1)
names(plot_sc9_crm1)= c("sampNum", "dose", "toxProb")
plot_sc9_crm1$design= rep("CRM1", nrow(plot_sc9_crm1))
plot_sc9_crm1$dose= as.factor(plot_sc9_crm1$dose)

plot_sc9_crm2 = reshape2::melt(toxProbMat9.CRM2)
names(plot_sc9_crm2)= c("sampNum", "dose", "toxProb")
plot_sc9_crm2$design= rep("CRM2", nrow(plot_sc9_crm2))
plot_sc9_crm2$dose= as.factor(plot_sc9_crm2$dose)

plot_sc9_smdfwo = reshape2::melt(toxProbMat9.wo)
names(plot_sc9_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc9_smdfwo$design= rep("SDF-woPD", nrow(plot_sc9_smdfwo))
plot_sc9_smdfwo$dose= as.factor(plot_sc9_smdfwo$dose)


plot_sc9_comb= rbind(plot_sc9_smdf, plot_sc9_crm1, plot_sc9_crm2,
                     plot_sc9_smdfwo)
plot_sc9_comb$design= as.factor(plot_sc9_comb$design)

true_sc9_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc9)
d.sc9= data.table(x= true_sc9_df$dose, y=true_sc9_df$toxProb)


p9 <- ggplot() + 
  geom_boxplot(data= plot_sc9_comb, 
               aes(x=dose, y=toxProb, fill= design))+ 
  labs(title="Post mean of DLT probability for Scenario 9",
       x="dose level", y = "DLT prob.")+ 
  geom_line(data= true_sc9_df,
            aes(x= dose, y= toxProb), linetype= "dashed",
            lwd= 1, col= 2)+
  geom_point(data= d.sc9, aes(x= x, y= y),
             shape= c(2,2,2,17,2), size= 3)
p9

