# Aug 12 2021
# 2-cpt models
# scen 1

doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas6.5pl= c(0.003, 0.76, 2.62, -1.80, 1.19) 

paramLst_pkpop_sc6= list(V= 29.3, sd_lV= 0.33, 
                         k= 0.97, sd_lk= 0.34, 
                         a= 0.15, a2= 0.13)


x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain= 3

targetProb= 0.3
ksi= 0.9
T0= 1/24

to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma","lambda", "a", "a2")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())


scenNum= 6
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStan1/scen6/traces/"
