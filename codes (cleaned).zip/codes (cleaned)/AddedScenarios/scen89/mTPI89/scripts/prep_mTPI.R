# May 2 2023
# prep scripts for mTPI
# scenarios 6 to 10 (additional scens)
# 6 to 7: 2 models misspec;
# 8 to 10: 3 models misspec.

library(pracma)


# 1-cpt single dose IV infusion model
pkConc.1cpt= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  k= psi[2]
  
  res1= D/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= D/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}


# functions to simulate data (the 5-PL PD model)
integrand.1co.5pl= function(x, log.psii, betas, dose) {
  beta1= betas[1]
  beta2= betas[2]
  beta3= betas[3]
  beta4= betas[4]
  beta5= betas[5]
  
  conc= pkConc.1cpt(time= x, dose= dose, log.psii= log.psii) 
  res= beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
  return(res)
}

expit= function(x) {
  return(exp(x)/(1+ exp(x)))
}

# data generation: fixed link function
link.1co.5pl2= function(dose, log.psii, betas, inte_range,
                        linkParam) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  eta= integral(fun= integrand.1co.5pl, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii,
                betas= betas)  
  return(expit(x= linkParam[1]+ linkParam[2]* log(eta)) )
}





# data generation model: 2-cpt PK + 5-PL PD models+ fixed link func.
simu_pkpd_5pl_1cht= function(paramLst_pkpop, 
                             pd_param, linkParam,
                             x_timePoints,
                             z_timePoints,
                             dose_mat, 
                             inte_range) {
    tBegin= inte_range[1]
    tRef= inte_range[2]
    N_indiv= nrow(dose_mat)
    
    # true values
    # PK param
    V= paramLst_pkpop$V
    sd_lV= paramLst_pkpop$sd_lV
    k= paramLst_pkpop$k
    sd_lk= paramLst_pkpop$sd_lk
    # sd for conc. measurements in log scale
    a= paramLst_pkpop$a
    # sd for PD biomarker in log scale
    a2= paramLst_pkpop$a2
    
    # gen. 1 dataset
    Time= list()
    X= list()
    N= NULL
    V_vec= NULL
    k_vec= NULL
    
    for(i in 1: N_indiv) {
        time= x_timePoints
        Time[[i]]= sort(time)
        Vi= rlnorm(n= 1, meanlog= log(V), sdlog = sd_lV)
        ki= rlnorm(n= 1, meanlog= log(k), sdlog= sd_lk)
        
        fi= pkConc.1cpt(time= Time[[i]], 
                    dose= dose_mat[i,],
                    log.psii= log(c(Vi, ki)) )
        X[[i]]= rlnorm(n= length(x_timePoints), meanlog= log(fi), 
                       sdlog = a)
        N[i]= length(X[[i]])
        V_vec[i]= Vi
        k_vec[i]= ki
    }
    
    # PD
    eta_vec= NULL
    p_vec= NULL
    Y_vec= NULL
    z_mat= NULL
    N_z= NULL
    Time_z= list()
    psii_mat= matrix(NA, nrow= N_indiv, ncol= 2)
    
    for(i in 1: N_indiv) {
        Time_z[[i]]= z_timePoints
        log_psii= log(c(V_vec[i], k_vec[i]))
        eff_i= sapply(1:length(z_timePoints), function(k) {
            integrand.1co.5pl(x= z_timePoints[k], 
                              log.psii= log_psii, 
                              betas= pd_param, 
                              dose= dose_mat[i,])
        })
        eta_vec[i]= integral(fun= integrand.1co.5pl, 
                             xmin= tBegin, xmax= tRef,
                             log.psii= log_psii, 
                             dose= dose_mat[i,],
                             betas= pd_param)
        p_vec[i]= expit(x= linkParam[1]+ linkParam[2]* log(eta_vec[i]) )
        Y_vec[i]= rbinom(n= 1, size= 1, prob= p_vec[i])
        z_mat= rbind(z_mat, 
                     rlnorm(n= length(z_timePoints), 
                            meanlog= log(eff_i), sdlog= a2) )
        psii_mat[i, ]= exp(log_psii)
        N_z[i]= ncol(z_mat)
    }
    # Time, X are lists, N, y are vectors
    lst= list(Time_x= Time, X= X, N= N, y= Y_vec, z_mat= z_mat,
              Time_z= Time_z, N_z= N_z,
              dose_mat= dose_mat,
              psii_mat= psii_mat,
              eta_vec= eta_vec)
    return (lst)
}


# a function to append new cohort data into existing data
# Time, X are lists, N, y are vectors
combine_data= function(dataLst, newdataLst) {
    n= length(newdataLst$Time_x)
    nExisting= length(dataLst$Time_x)
    # append to existing data
    for(i in 1: n) {
        dataLst$Time_x[[nExisting+ i]]= newdataLst$Time_x[[i]]
        dataLst$Time_z[[nExisting+ i]]= newdataLst$Time_z[[i]]
        dataLst$X[[nExisting+ i]]= newdataLst$X[[i]]
        dataLst$N[nExisting+ i]= newdataLst$N[i]
        dataLst$N_z[nExisting+ i]= newdataLst$N_z[i]
        dataLst$y[nExisting+ i]= newdataLst$y[i]
        dataLst$z_mat= rbind(dataLst$z_mat, 
                             newdataLst$z_mat[i,])
        dataLst$dose_mat= rbind(dataLst$dose_mat, 
                                newdataLst$dose_mat[i,])
        dataLst$psii_mat= rbind(dataLst$psii_mat, 
                                newdataLst$psii_mat[i,])
        dataLst$eta_vec[nExisting+i]= newdataLst$eta_vec[i] 
    }
    return(dataLst)
}


# CRM w/ data simulate from 2-cpt PK w/ 5-PL PD model
# ntrial= num of simulations

# a func to return dose index/ level
convertToDoseIndex= function(dose, doseRef) {
    for(i in 1: length(doseRef)) {
        if(doseRef[i]== dose) { return(i) }
    } # end of for loop
}


##########################
# run mTPI design (beta-binom conjugate posterior for p_i)

## pava= pooled adjacent violator algorithm to perform isotonic transformation for the posterior means later
pava <- function (x, wt = rep(1, length(x))) {
    n <- length(x)
    if (n <= 1) 
        return(x)
    if (any(is.na(x)) || any(is.na(wt))) {
        stop("Missing values in 'x' or 'wt' not allowed")
    }
    lvlsets <- (1:n)
    repeat {
        viol <- (as.vector(diff(x)) < 0)
        if (!(any(viol))) 
            break
        i <- min((1:(n - 1))[viol])
        lvl1 <- lvlsets[i]
        lvl2 <- lvlsets[i + 1]
        ilvl <- (lvlsets == lvl1 | lvlsets == lvl2)
        x[ilvl] <- sum(x[ilvl] * wt[ilvl])/sum(wt[ilvl])
        lvlsets[ilvl] <- lvl1
    }
    return(x)
}

## betavar computes variances of beta distributions 

betavar<-function(a,b){
    resp <- a*b/((a+b)^2*(a+b+1))
    return(resp)
}



# safe rule, evaluated for dose (kappa_star)
calcEmpProp= function(pi_vec, targetProb) {
    # pi_vec contains samples of avg tox prob for a dose
    return(mean(pi_vec > targetProb))
}

# safe= 1, unsafe= 0
isSafe= function(pi_vec, targetProb, ksi) {
    safeFlag= 1
    empProp= calcEmpProp(pi_vec= pi_vec, targetProb= targetProb)
    
    # when the dose is not safe
    if(empProp > ksi) {
        safeFlag= 0
    }
    return(safeFlag) 
}



#decision rules, based on mTPI
# a func. to return a recommended dose for next cohort 
# regardless of whether the trial is to continue
# currDoseIdx: an integer, ranging from 1:nDoses
# pi_vec_atCurrDose: a numeric vector
# mTPI_params= c(eps1, eps2), a numeric vector
# targetProb: a scalar (real number)
calc_nextDose= function(currDoseIdx, pi_vec_atCurrDose,
                        mTPI_params, targetProb) {
    eps1= mTPI_params[1]
    eps2= mTPI_params[2]
    
    # bounds for the intervals that partition (0,1) interval 
    # into 3 subintervals
    lBound= targetProb- eps1
    uBound= targetProb+ eps2
    S= length(pi_vec_atCurrDose)
    
    #lengths of left, EI, and right intervals
    lLen= lBound- 0.0
    eiLen= uBound- lBound
    rLen= 1.0- uBound; 
    
    lCount= 0
    eiCount= 0
    rCount= 0
    
    for(s in 1: S) {
        if(pi_vec_atCurrDose[s]> 0.0 & pi_vec_atCurrDose[s]< lBound) { 
            lCount= lCount+ 1
        }
        else if(pi_vec_atCurrDose[s]>= lBound & 
                pi_vec_atCurrDose[s]<= uBound) {
            eiCount= eiCount+ 1
        }
        else {
            rCount= rCount+ 1
        }
    }
    
    #UPM= prob of X in the interval/ interval_len
    lUPM= (lCount/S)/ lLen
    eiUPM= (eiCount/S)/ eiLen
    rUPM= (rCount/S)/ rLen
    #print(round(c(lUPM, eiUPM, rUPM), 3))
    
    maxUPM= max( c(lUPM, eiUPM, rUPM) )
    # stay at currDose if ei has largest UPM
    if(maxUPM== eiUPM) {
        nextDoseIdx= currDoseIdx
    }
    #escalate if left interval has largest UPM
    else if(maxUPM== lUPM) {
        nextDoseIdx= currDoseIdx+ 1
    }
    # de-escalate if right interval has largest UPM
    else if(maxUPM== rUPM) {
        nextDoseIdx= currDoseIdx- 1
    }
    return(nextDoseIdx)
}


# simulate data for 1 trial 
# SMDF w/ mTPI rule based on plug-in estimator
# T0 is the infusion end time (real type)
# cohortSize: integer, num of indiv to enter for a dose level at an occasion
# maxNum: integer, trial to end when maxNum patients completed the trial
# paramLst_pkpop: a list containing pkpop param true values
# pd_param_5pl: a list containing pd param true values
# timePoints: a vector, fixed for each cohort
# inte_range: from 0 to t_ref, for cum. pd effect
# T0: infusion duration
# doseVec: a vector of the doses to explore
# hyperLst_pkpd: a list of hyper param
# initLst_pkpd: a list of initial values for pkpop and pd params
# S: num of iterations
# nBurnin: num of burn-in samples to discard
# thin: an integer, take out every thinth samples
# targetProb: target tox prob
# ksi: safety threshold for pi, w/ Pr(pi>targetProb|data)>= ksi indicating too toxic
# eps1 and eps2: tuning param for mTPI rule
# B: num of samples to draw for each post sample of pkpop and pd for computing average pi
# scen, nSim: aux variables to help trace plots and dataset storation
run_1_trial_mTPI= function(cohortSize=3, 
                           maxNum= 30,
                           paramLst_pkpop, 
                           pd_param_5pl, linkParam,
                           x_timePoints,
                           z_timePoints,
                           inte_range, 
                           T0, doseVec,
                           targetProb=0.3, ksi, 
                           eps1=0.05, eps2=0.05) {
    # max possible num of cohorts for a simulated trial
    max_nCohorts= maxNum/ cohortSize
    # num of doses
    maxDoseLevel= length(doseVec)
    # num of doses after toxicity exclusion from right
    # maxDoseLevel2 <= maxDoseLevel
    maxDoseLevel2= maxDoseLevel
    
    # for each incoming cohort, store the following info:
    # at each dose dose level: events and cohortSize
    mat1= cbind(1:maxDoseLevel,
                rep(0, maxDoseLevel),
                rep(0, maxDoseLevel))
    # store progress matrix
    mat2= NULL
    # store safety monitoring matrix: Pr(pi>p_T) for each dose 
    mat3= NULL
    y_mat= NULL
    
    piMat= matrix(0, nrow= 1000, ncol= maxDoseLevel)
    
    # matrix of tried doses
    triedDoses_mat= NULL
    # 1=tried, 0=untried
    triedDoseVec= rep(0, maxDoseLevel)
    
    # current dose index
    doseIdx= 1
    # cum. data list
    cum_datLst= NULL
    # round counter
    counter= 0
    # cumulative number of patients in study
    cumNum= 0
    # flag variable for safety rules
    contiFlag= 1
    
    # the trial will end if any of the following is met:
    # (1) dose 1 is found to be too toxic (w/ increasing toxicity assu.)
    # (2) maxNum of patients already enrolled
    while(contiFlag== 1 & cumNum< maxNum) {
        counter= counter+ 1
        #print("#Round:")
        #print(counter)
        
        currDose= doseVec[doseIdx]
        # update tried dose vector
        triedDoseVec[doseIdx]= 1
        #print("dose level tried:")
        #print(triedDoseVec)
        triedDoses_mat= rbind(triedDoses_mat, triedDoseVec)
        
        # enroll a cohort of patients to treat at currDose
        curr_datLst= simu_pkpd_5pl_1cht(
            paramLst_pkpop=paramLst_pkpop, 
            pd_param= pd_param_5pl, 
            linkParam= linkParam,
            x_timePoints= x_timePoints,
            z_timePoints= z_timePoints,
            dose_mat=cbind(rep(T0, cohortSize), 
                           rep(currDose, cohortSize)), 
            inte_range= inte_range)
        
        # append new data to existing data
        cum_datLst= combine_data(dataLst=cum_datLst, 
                                 newdataLst= curr_datLst)
        # update num of patients in study
        cumNum= cumNum+ cohortSize
        
        # num of tox. events at each dose
        mat1[doseIdx,2]= mat1[doseIdx,2]+ sum(curr_datLst$y)
        # num of patients treated at each dose
        mat1[doseIdx,3]= mat1[doseIdx,3]+ cohortSize
        #print(mat1)
        
        piMat= sapply(1:maxDoseLevel, function(x) {
            rbeta(n=1000, 
                  shape1= 1+ mat1[x,2],
                  shape2= 1+ mat1[x,3]- mat1[x,2])
        } )
        
        mat3_row_i= sapply(c(1:maxDoseLevel), function(x) {
            calcEmpProp(pi_vec= piMat[,x], targetProb=targetProb)
        })
        
        #print(paste("pi=", mean(piMat[,doseIdx]> targetProb)) )
        
        if(doseIdx+1 <= maxDoseLevel) {
            #print(paste("piplus1=", mean(piMat[,doseIdx+1]> targetProb)) )
            
            piiandpip1= c(mean(piMat[,doseIdx]> targetProb),
                          mean(piMat[,doseIdx+1]> targetProb))
        } else {
            piiandpip1= c(mean(piMat[,doseIdx]> targetProb), NA)
        }
        
        # safe=1 => continue; safe=0 => dis-continue to early terminate
        contiFlag= isSafe(pi_vec= piMat[,1],
                          targetProb=targetProb, ksi= ksi)
        
        if(contiFlag== 1) {
            # recommend next dose based on current dose
            recom_doseIdx= calc_nextDose(currDoseIdx=doseIdx, 
                                         pi_vec_atCurrDose= piMat[,doseIdx],
                                         mTPI_params= c(eps1, eps2), 
                                         targetProb= targetProb)
            
            if((recom_doseIdx <= maxDoseLevel2) & recom_doseIdx >= 1){
                # if to escalate to a very toxic dose
                if(recom_doseIdx== doseIdx+ 1 ) {
                    piplus1= mean(piMat[,doseIdx+1]> targetProb)
                    # decrease maxDoseLevel if next dose is too toxic
                    if(piplus1>= ksi) {
                        maxDoseLevel2= doseIdx
                        recom_doseIdx= doseIdx
                    }
                }
            }
            else if(recom_doseIdx > maxDoseLevel2){
                recom_doseIdx= maxDoseLevel2
            }
            # if to de-escalate from dose 1
            else if(recom_doseIdx< 1) {
                recom_doseIdx= 1
            }
        }
        else if(contiFlag== 0) {
            recom_doseIdx= 0
        }
        # append progress matrix
        mat2= rbind(mat2, 
                    c(cumNum, contiFlag, doseIdx,
                      colMeans(piMat), 
                      piiandpip1, recom_doseIdx,
                      sum(curr_datLst$y), cohortSize))
        y_mat_row_i= c(doseIdx, sum(curr_datLst$y), cohortSize)
        
        mat3= rbind(mat3, mat3_row_i)
        
        y_mat= rbind(y_mat, y_mat_row_i)
        
        #print("Roundwise pi, dose recomm. and #events:")
        #print(round(mat2[c(1:(cumNum/cohortSize)),],3))
        
        #print("Roundwise safety prob. matrix for each dose:")
        #print(round(mat3[c(1:(cumNum/cohortSize)),],3))
        #print("Roundwise #events at tried doses:")
        #print(t(sapply(by(y_mat, y_mat[,1], colSums),identity))[,2])
        
        # update dose assignment for next cohort
        doseIdx= recom_doseIdx
        
    } # end of while loop
    
    nEvent= sum(cum_datLst$y)
    doseTrt= as.vector(table(factor(y_mat[,1], levels= 1:maxDoseLevel)))
    
    tdose<- maxDoseLevel2 
    
    if(recom_doseIdx != 0) {
        ##pp <- rep(-100, D)
        pp<-rep(-100,tdose)
        pp.var<-rep(0, tdose)
        ##pp.var <- rep(0, D)
        
        ##for(i in maxdose:(toxdose-1)){
        for(i in 1:tdose){
            pp[i] <- (mat1[i,2]+0.005)/(mat1[i, 3]+0.01); 
            pp.var[i] <- betavar(mat1[i,2]+0.005, 
                                 mat1[i,3]-mat1[i,2]+0.005) 
            ### here adding 0.005 is to use beta(0.005, 0.005) for estimating the MTD, which is different from the dose-finding.
        }
        pp<-pava(pp, wt=1/pp.var) 
        ##pp[maxdose:(toxdose-1)]<-pava(pp[maxdose:(toxdose-1)], wt=1/pp.var[maxdose:(toxdose-1)])  ## perform the isotonic transformation using PAVA with weights being posterior variances
        
        ##for(i in maxdose:(toxdose-1)){
        for(i in 2:tdose){
            pp[i] <- pp[i] + i*1E-10 ## by adding an increasingly small number to tox prob at higher doses, it will break the ties and make the lower dose level the MTD if the ties were larger than pT or make the higher dose level the MTD if the ties are smaller than pT
        }
        MTD<-sort(abs(pp- targetProb), index.return=T)$ix[1]
    }
    else if(recom_doseIdx== 0){
        MTD= 0
    }
    
    # when MTD is among the doses
    if(MTD> 0) {
        MTDProb= mean(piMat[,MTD])
    }
    # when a trial is ended earlier => inconclusive MTD
    else if(MTD== 0) {
        MTDProb= NA
    }
    return(list(mat1= mat1, mat2= mat2, y_mat= y_mat,
                nEvent= nEvent, nPts= cumNum,
                adj_maxDoseLevel= maxDoseLevel2, MTD= MTD,
                MTDProb= MTDProb,
                res=cohortSize* doseTrt))
}

run_mTPI_sim= function(cohortSize=3, 
                       maxNum= 30,
                       paramLst_pkpop, 
                       pd_param_5pl,
		       linkParam,
                       x_timePoints,
                       z_timePoints,
                       inte_range, 
                       T0, doseVec,
                       targetProb=0.3, ksi= 0.95, 
                       eps1=0.05, eps2=0.05,
                       nSim) {
    MTD_vec= NULL
    res_mat= NULL 
    totalNum_vec= NULL
    eventNum_vec= NULL
    
    for(i in 1: nSim) {
        out= run_1_trial_mTPI(cohortSize= cohortSize, 
                              maxNum= maxNum,
                              paramLst_pkpop= paramLst_pkpop, 
                              pd_param_5pl= pd_param_5pl,
                              linkParam= linkParam,
                              x_timePoints= x_timePoints,
                              z_timePoints= z_timePoints,
                              inte_range= inte_range, 
                              T0= T0, doseVec= doseVec,
                              targetProb=targetProb, ksi= ksi, 
                              eps1=eps1, eps2=eps2)
        MTD_vec[i]= out$MTD
        res_mat= rbind(res_mat, out$res)
        totalNum_vec[i]= sum(out$nPts)
        eventNum_vec[i]= sum(out$nEvent)
    }
    return(list(selProb= table(MTD_vec)/nSim,
                avgPtsAllo= colSums(res_mat)/nSim,
                avgtotalPts= mean(totalNum_vec),
                avgEventNum= mean(eventNum_vec),
                avgToxProb= sum(eventNum_vec)/ sum(totalNum_vec)))
}
