# Aug 12 2021
# 2-cpt models
# scen 5


doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas5.5pl= c(0.02, 0.335, 8.008, -0.64, 1.3) 

# settings for scen 5
#paramLst_pkpop_sc5= list(V= 33, sd_lV= 0.19, 
#                         alpha= 9.2, sd_lalpha= 0.13,
#                         beta= 0.14, sd_lbeta= 0.13, 
#                         k21= 6.3, sd_lk21= 0.11, 
#                         a= 0.2, a2= 0.1)

paramLst_pkpop_sc5= list(V= 33, sd_lV= 0.36, 
                         alpha= 9.2, sd_lalpha= 0.33,
                         beta= 0.14, sd_lbeta= 0.30, 
                         k21= 6.3, sd_lk21= 0.35, 
                         a= 0.2, a2= 0.15)


x.timePoints= c(1, 3, 6, 12, 24, 48)/24

z.timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain=3

targetProb= 0.3
ksi= 0.9
T0= 1/24

# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(33,9.2,0.14,6.3)), 
                 betas= betas5.5pl, 
                 inte_range= c(0,21))
})
print(true.pi)


scenNum= 5
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanb/scen5/traces/"


to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma","lambda", "a", "a2")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())


