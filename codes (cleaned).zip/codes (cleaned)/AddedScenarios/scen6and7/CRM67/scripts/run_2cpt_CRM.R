# Mar 17 2023

# load relevant scripts
source("prep_CRM.R")

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)
targetProb= 0.3
ksi= 0.9
T0= 1/24


doseVec= c(10,30,60,90,150)
doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas6.5pl= c(0.003, 0.76, 2.62, -1.80, 1.19) 
betas7.5pl= c(0.003, 0.934, 1.61, -1.45, 1.59)


# settings for scen 6
paramLst_pkpop_sc6= list(V= 29.3, sd_lV= 0.33, 
                         k21= 0.97, sd_lk21= 0.34, 
                         a= 0.15, a2= 0.13)

# 2 prior skeletons for CRM
p0.1 = dfcrm::getprior(halfwidth= 0.05, target= 0.3, 
                       nu=3, nlevel= 5, model="empiric") 
print(p0.1)


p0.2 = dfcrm::getprior(halfwidth= 0.075, target= 0.3, 
                     nu=3, nlevel= 5, model="empiric") 
print(p0.2)


# scen 1
print("scen 1")
# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.1co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(29.3,0.97)), 
                 betas= betas6.5pl, 
                 inte_range= c(0,21))
})

true.pi


# for CRM1
print("CRM1")

set.seed(101)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc6, 
                pd_param_5pl= betas6.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen6","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(107)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc6, 
                pd_param_5pl= betas6.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen6","_res_CRM2",".rds", sep= ''))


# scen 7
print("scen 7")
true.pi= sapply(1:5, function(x) {
    link.1co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(30.2, 0.98)), 
                 betas= betas7.5pl, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc7= list(V= 30.2, sd_lV= 0.33, 
                         k21= 0.98, sd_lk21= 0.32, 
                         a= 0.13, a2= 0.14)


# for CRM1
print("CRM1")

set.seed(10)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc7, 
                pd_param_5pl= betas7.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen7","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(10)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc7, 
                pd_param_5pl= betas7.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen7","_res_CRM2",".rds", sep= ''))

