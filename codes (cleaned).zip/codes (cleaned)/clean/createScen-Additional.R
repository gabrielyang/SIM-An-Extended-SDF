# Mar 14 2023
# construct dose-tox scenarios using 1-cpt IV infusion model

library(pracma)

# 1-cpt single dose IV bolus model
oneComp.pk= function(time, psi, D) {
    k= psi[1]
    V= psi[2]
    D/V*exp(-k* time)
}

# 1-cpt single dose IV infusion model
pkConc.1cpt= function(time, dose, T0, log.psi) {
  psi= exp(log.psi)
  V= psi[1]
  k= psi[2]
  res1= dose/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= dose/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}

# PD effect under 5PL model
# x= time, betas=PD params, log.psii= PK params, dose= dose
integrand.5PL= function(x, betas, log.psii, dose, T0) {
    beta1= betas[1]
    beta2= betas[2]
    beta3= betas[3]
    beta4= betas[4]
    beta5= betas[5]
    
    psii= exp(log.psii)
    conc= pkConc.1cpt(time= x, dose=dose, T0=T0, log.psi= log.psii)
    beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
}


# link func. => DLT prob.
# the original link function
link.5PL= function(dose, T0, log.psii, betas, inte_range) {
    t.begin= inte_range[1]
    t.ref= inte_range[2]
    eta= integral(fun= integrand.5PL, xmin=t.begin, xmax=t.ref,
                  dose= dose, T0= T0, log.psii= log.psii,
                  betas= betas)  
    return(1- exp(-eta))
}

# link function 2 (logit link)
link.5PL2= function(dose, T0, log.psii, betas, inte_range,
                    linkParam) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  eta= integral(fun= integrand.5PL, xmin=t.begin, xmax=t.ref,
                dose= dose, T0= T0, log.psii= log.psii,
                betas= betas)  
  return(expit(x= linkParam[1]+ linkParam[2]*log(eta)) )
}

link.eta= function(dose, T0, log.psii, betas, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  eta= integral(fun= integrand.5PL, xmin=t.begin, xmax=t.ref,
                dose= dose, T0= T0, log.psii= log.psii,
                betas= betas)  
  return(eta)
}


# average across indiv. DLT prob. for each dose => average DLT prob. at each dose 
calcDLTProb= function(dose, T0, log.psi, sd.psi,
                      betas, inte_range, B) {
    psiMat= cbind(rlnorm(n= B, meanlog= log.psi[1], sdlog= sd.psi[1]),
                  rlnorm(n= B, meanlog= log.psi[2], sdlog= sd.psi[2]))
    piVec= sapply(1:B, function(b) {
        link.5PL(dose= dose, T0=T0, log.psii= log(psiMat[b,]), 
                 betas= betas, inte_range= inte_range)
    })
    return(mean(piVec))
}

calcDLTProb2= function(dose, T0, log.psi, sd.psi,
                       betas, inte_range, B, linkParam) {
  psiMat= cbind(rlnorm(n= B, meanlog= log.psi[1], sdlog= sd.psi[1]),
                rlnorm(n= B, meanlog= log.psi[2], sdlog= sd.psi[2]))
  piVec= sapply(1:B, function(b) {
    link.5PL2(dose= dose, T0=T0, log.psii= log(psiMat[b,]), 
              betas= betas, inte_range= inte_range, 
              linkParam=linkParam)
  })
  return(mean(piVec))
}


calcEta= function(dose, T0, log.psi, sd.psi,
                       betas, inte_range, B) {
  psiMat= cbind(rlnorm(n= B, meanlog= log.psi[1], sdlog= sd.psi[1]),
                rlnorm(n= B, meanlog= log.psi[2], sdlog= sd.psi[2]))
  piVec= sapply(1:B, function(b) {
    link.eta(dose= dose, T0=T0, log.psii= log(psiMat[b,]), 
              betas= betas, inte_range= inte_range)
  })
  return(mean(piVec))
}


expit= function(x) {
    return(exp(x)/ (1+ exp(x)))
}

# grid of doses
doseInc= c(10,30,60,90,150)



#######################
# scen 6
# 29.3 (0.33), 0.97 (0.34); 0.15, 0.13
betas6= c(0.003, 0.76, 2.62, -1.80, 1.19) # 0.07 0.11 0.21 0.31 0.46
# scen 7
# 30.2 (0.33), 0.98 (0.32); 0.13, 0.14
betas7= c(0.003, 0.934, 1.61, -1.45, 1.59) #  0.07 0.16 0.30 0.43 0.58

# scen 6
set.seed(123)
toxProb1= sapply(1:5, function(k) {
  calcDLTProb(dose= doseInc[k], T0=1/24,
              log.psi= log(c(29.3, 0.97)), sd.psi= c(0.33,0.34),
              betas= betas6, inte_range= c(0,21), B= 1000) 
})
round(toxProb1,2)

# scen 7
set.seed(123)
toxProb1= sapply(1:5, function(k) {
  calcDLTProb(dose= doseInc[k], T0=1/24,
              log.psi= log(c(30.2, 0.98)), sd.psi= c(0.33,0.32),
              betas= betas7, inte_range= c(0,21), B= 1000) 
})
round(toxProb1,2)

###################################
betas8= c(0.001, 0.419, 1.691, -0.793, 1.462)
betas9= c(0.001, 0.483, 1.688, -0.814, 1.456)

# scen 8
set.seed(1)
toxProb2= sapply(1:5, function(k) {
  calcDLTProb2(dose= doseInc[k], T0=1/24,
              log.psi= log(c(29.5, 0.8)), sd.psi= c(0.3,0.3),
              betas= betas8, inte_range= c(0,21), B= 1000,
              linkParam= c(0.682, 1.303)) 
})
round(toxProb2,2)

# scen 9
set.seed(1)
toxProb2= sapply(1:5, function(k) {
  calcDLTProb2(dose= doseInc[k], T0=1/24,
               log.psi= log(c(28, 0.82)), sd.psi= c(0.32,0.32),
               betas= betas9, inte_range= c(0,21), B= 1000,
               linkParam= c(1.060, 1.319)) 
})
round(toxProb2,2)

