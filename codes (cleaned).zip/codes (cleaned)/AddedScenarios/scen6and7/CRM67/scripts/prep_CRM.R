# Mar 17 2023
# data generation model: 1-cpt IV infusion PK + 5PL PD + fixed link function
# prep scripts for CRM

# dose-finding designs for comparison
library(dfcrm)
library(bcrm)
library(pracma)


# 1-cpt single dose IV infusion model
pkConc.1cpt= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  k= psi[2]
  
  res1= D/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= D/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}


# functions to simulate data (the 5-PL PD model)
integrand.1co.5pl= function(x, log.psii, betas, dose) {
    beta1= betas[1]
    beta2= betas[2]
    beta3= betas[3]
    beta4= betas[4]
    beta5= betas[5]
    
    conc= pkConc.1cpt(time= x, dose= dose, log.psii= log.psii) 
    res= beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
    return(res)
}

# data generation: fixed link function
link.1co.5pl= function(dose, log.psii, betas, inte_range) {
    t.begin= inte_range[1]
    t.ref= inte_range[2]
    
    eta= integral(fun= integrand.1co.5pl, 
                  xmin=t.begin, xmax=t.ref,
                  dose= dose, log.psii= log.psii,
                  betas= betas)  
    return(1- exp(-eta))
}


# data generation model: 2-cpt PK + 5-PL PD models+ fixed link func.
simu_pkpd_5pl_1cht= function(paramLst_pkpop, 
                             pd_param,
                             x_timePoints,
                             z_timePoints,
                             dose_mat, 
                             inte_range) {
    tBegin= inte_range[1]
    tRef= inte_range[2]
    N_indiv= nrow(dose_mat)
    
    # true values
    # PK param
    V= paramLst_pkpop$V
    sd_lV= paramLst_pkpop$sd_lV
    k= paramLst_pkpop$k
    sd_lk= paramLst_pkpop$sd_lk
    # sd for conc. measurements in log scale
    a= paramLst_pkpop$a
    # sd for PD biomarker in log scale
    a2= paramLst_pkpop$a2
    
    # gen. 1 dataset
    Time= list()
    X= list()
    N= NULL
    V_vec= NULL
    k_vec= NULL
    
    for(i in 1: N_indiv) {
        time= x_timePoints
        Time[[i]]= sort(time)
        Vi= rlnorm(n= 1, meanlog= log(V), sdlog = sd_lV)
        ki= rlnorm(n= 1, meanlog= log(k), sdlog= sd_lk)
        
        fi= pkConc.1cpt(time= Time[[i]], 
                    dose= dose_mat[i,],
                    log.psii= log(c(Vi, ki)) )
        X[[i]]= rlnorm(n= length(x_timePoints), meanlog= log(fi), 
                       sdlog = a)
        N[i]= length(X[[i]])
        V_vec[i]= Vi
        k_vec[i]= ki
    }
    
    # PD
    eta_vec= NULL
    p_vec= NULL
    Y_vec= NULL
    z_mat= NULL
    N_z= NULL
    Time_z= list()
    psii_mat= matrix(NA, nrow= N_indiv, ncol= 2)
    
    for(i in 1: N_indiv) {
        Time_z[[i]]= z_timePoints
        log_psii= log(c(V_vec[i], k_vec[i]))
        eff_i= sapply(1:length(z_timePoints), function(k) {
            integrand.1co.5pl(x= z_timePoints[k], 
                              log.psii= log_psii, 
                              betas= pd_param, 
                              dose= dose_mat[i,])
        })
        eta_vec[i]= integral(fun= integrand.1co.5pl, 
                             xmin= tBegin, xmax= tRef,
                             log.psii= log_psii, 
                             dose= dose_mat[i,],
                             betas= pd_param)
        p_vec[i]= 1- exp(- eta_vec[i])
        Y_vec[i]= rbinom(n= 1, size= 1, prob= p_vec[i])
        z_mat= rbind(z_mat, 
                     rlnorm(n= length(z_timePoints), 
                            meanlog= log(eff_i), sdlog= a2) )
        psii_mat[i, ]= exp(log_psii)
        N_z[i]= ncol(z_mat)
    }
    # Time, X are lists, N, y are vectors
    lst= list(Time_x= Time, X= X, N= N, y= Y_vec, z_mat= z_mat,
              Time_z= Time_z, N_z= N_z,
              dose_mat= dose_mat,
              psii_mat= psii_mat,
              eta_vec= eta_vec)
    return (lst)
}


# a function to append new cohort data into existing data
# Time, X are lists, N, y are vectors
combine_data= function(dataLst, newdataLst) {
    n= length(newdataLst$Time_x)
    nExisting= length(dataLst$Time_x)
    # append to existing data
    for(i in 1: n) {
        dataLst$Time_x[[nExisting+ i]]= newdataLst$Time_x[[i]]
        dataLst$Time_z[[nExisting+ i]]= newdataLst$Time_z[[i]]
        dataLst$X[[nExisting+ i]]= newdataLst$X[[i]]
        dataLst$N[nExisting+ i]= newdataLst$N[i]
        dataLst$N_z[nExisting+ i]= newdataLst$N_z[i]
        dataLst$y[nExisting+ i]= newdataLst$y[i]
        dataLst$z_mat= rbind(dataLst$z_mat, 
                             newdataLst$z_mat[i,])
        dataLst$dose_mat= rbind(dataLst$dose_mat, 
                                newdataLst$dose_mat[i,])
        dataLst$psii_mat= rbind(dataLst$psii_mat, 
                                newdataLst$psii_mat[i,])
        dataLst$eta_vec[nExisting+i]= newdataLst$eta_vec[i] 
    }
    return(dataLst)
}


# CRM w/ data simulate from 2-cpt PK w/ 5-PL PD model
# ntrial= num of simulations

# a func to return dose index/ level
convertToDoseIndex= function(dose, doseRef) {
    for(i in 1: length(doseRef)) {
        if(doseRef[i]== dose) { return(i) }
    } # end of for loop
}


# skeleton stores the prior (initial guess of DLT prob for each dose)
run_crm_sim= function(paramLst_pkpop, 
                      pd_param_5pl,
                      x_timePoints,
                      z_timePoints,
                      T0, 
                      cohortSize=3, 
                      maxNum= 30, 
                      doseVec, 
                      inte_range,
                      skeleton,
                      targetProb= 0.3,
                      safetyCutoff= 0.95, 
                      nSim){
    # number of doses under investigation
    numDose=length(doseVec)
    # number of cohorts
    numCohort= maxNum/ cohortSize
    
    # a vector to store MTD dose index for each simulation/trial
    MTD_vec= NULL
    numEvent_vec= NULL
    totalTreated_vec= NULL
    # patients can only be treated at 1:numDose dose levels
    numTreated_mat= NULL
    toxProbMat= matrix(NA, nrow= nSim, ncol= numDose)
    DLTProbMatLst= NULL
    
    for(nsim in 1: nSim){
        numTreated= rep(0, numDose)
        totalTreated= 0
        cum_datLst= NULL
        d= 1
        ### simulate data for each of the cohort
        for (i in 1: numCohort) {
            #currentDoseLevel= d
            numTreated[d]= numTreated[d]+ cohortSize
            totalTreated= totalTreated+ cohortSize
            
            # dosage at this dose level
            currDose= doseVec[d]
            
            curr_datLst= simu_pkpd_5pl_1cht(
                paramLst_pkpop=paramLst_pkpop, 
                pd_param= pd_param_5pl,
                x_timePoints= x_timePoints,
                z_timePoints= z_timePoints,
                dose_mat=cbind(rep(T0, cohortSize), 
                               rep(currDose, cohortSize)), 
                inte_range= inte_range)
            
            # append new data to existing data
            cum_datLst= combine_data(dataLst= cum_datLst, 
                                     newdataLst= curr_datLst)
            
            patientID= 1:length(cum_datLst$y)
            # convert from dose to dose index
            doseIndex= sapply(cum_datLst$dose_mat[,2], 
                              function(x) {
                                  convertToDoseIndex(
                                      dose= x, 
                                      doseRef= doseVec)
                              })
            # format the data
            data1= data.frame(patient=patientID,
                              dose= doseIndex,
                              tox= cum_datLst$y)
            
            res= bcrm(stop=list(nmax= nrow(data1), 
                                safety=safetyCutoff),
                      data= data1, 
                      p.tox0= skeleton, 
                      method="rjags",
                      ff="power", 
                      prior.alpha=list(3,0,1.34^2),
                      target.tox= targetProb,
                      constrain= TRUE, 
                      cohort= cohortSize,
                      sdose.calculate="mean", 
                      pointest="plugin",
                      #start=1,
                      quietly=TRUE,
                      threep3=FALSE)
            
            # update to MTD
            d= res$ndose[[1]]$ndose
            if(d==0) break
            if(d> numDose) {d= numDose }
        }
        #print(paste("totalTreated=", totalTreated))
        #print(numTreated)
        #print(paste("numEvent=", sum(cum_datLst$y)))
        MTD_vec= c(MTD_vec, d)
        totalTreated_vec= c(totalTreated_vec, totalTreated)
        numEvent_vec= c(numEvent_vec, sum(cum_datLst$y))
        numTreated_mat= rbind(numTreated_mat, numTreated)
        # store DLT prob for each dose at the end of trial
        if(d != 0) { 
            toxProbMat[nsim, ]= res$ndose[[1]]$est
        }
        DLTProbMatLst[[nsim]]= res$ndose[[1]]$quantiles[c(1,6), ]
    }
    
    # limit to complete cases
    toxProbMat= toxProbMat[complete.cases(toxProbMat),]
    
    allocationNum= colMeans(numTreated_mat)
    MTD_vec= factor(MTD_vec, levels = 0:length(skeleton) )
    selProb=table(MTD_vec)/nSim
    toxProb= sum(numEvent_vec)/ sum(totalTreated_vec)
    #NApercent=1-sum(SelectionProbablity)
    return(list(selProb= selProb,
                allocationNum= allocationNum,
                toxProb= toxProb,
                Npt= mean(totalTreated_vec),
                numTreated_mat= numTreated_mat,
                toxProbMat= toxProbMat,
                DLTProbMatLst= DLTProbMatLst) )
}

