# Apr 17 2022
# run trial simulation for aim-2 2-cpt models
# scen 4

# load relevant scripts
library(Rcpp)
library(rstan)
sourceCpp("piMat0416.cpp")
mod= stan_model("sdfwpd0414.stan")
source("trialProg_2cpt.R")

source("setting_2cpt_scen4.R")


set.seed(101)

for(nSim in 1: 20) {
print(nSim)

    oo2= run_1_trial_2cpt(cohortSize=3, 
                          maxNum= 30,
                          paramLst_pkpop= paramLst_pkpop_sc4, 
                          pd_param_5pl= betas4.5pl,
                          x_timePoints= x.timePoints, 
                          z_timePoints= z.timePoints,
                          inte_range= inte_range, 
                          T0= T0, doseVec= doseInc,
                          hyperLst_pkpd= hyperLst_pkpd_sc4,
                          initLst_pkpd = initLst_pkpd_sc4,
                          S= S, nBurnin= nBurnin, thin= thin, 
                          nchain=nchain,
                          targetProb= targetProb, ksi= ksi, 
                          nSim= nSim, scen= scenNum,
                          path= path1, to_plot=to_plot)
    saveRDS(oo2, file= paste("scen",scenNum, "_res_", nSim,".rds", sep= ''))
}

