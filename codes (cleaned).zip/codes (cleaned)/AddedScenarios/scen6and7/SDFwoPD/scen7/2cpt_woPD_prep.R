# Apr 30 2023
# script for 2-cpt models (SMDF w/o PD)
# w/o PD measurements
# working models: 2-cpt IV infusion PK model (1 dose given at time T0)+ 
# sigmoid Emax PD model+ 
# 1-param link function (p_i= 1-exp(- lambda* eta_i))
# data generating models: 2-cpt IV infusion PK model+
# 5-PL PD model+ fixed link function (p_i= 1-exp(-eta_i))

library(Rcpp)
#library(RcppNumerical)
library(pracma)
library(rstan)


# 1-cpt single dose IV infusion model
pkConc.1cpt= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  k= psi[2]
  
  res1= D/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= D/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}


# functions to simulate data (the 5-PL PD model)
integrand.1co.5pl= function(x, log.psii, betas, dose) {
  beta1= betas[1]
  beta2= betas[2]
  beta3= betas[3]
  beta4= betas[4]
  beta5= betas[5]
  
  conc= pkConc.1cpt(time= x, dose= dose, log.psii= log.psii) 
  res= beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
  return(res)
}

# data generation: fixed link function
link.1co.5pl= function(dose, log.psii, betas, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  eta= integral(fun= integrand.1co.5pl, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii,
                betas= betas)  
  return(1- exp(-eta))
}


# data generation model: 2-cpt PK + 5-PL PD models+ fixed link func.
simu_pkpd_5pl_1cht= function(paramLst_pkpop, 
                             pd_param,
                             x_timePoints,
                             z_timePoints,
                             dose_mat, 
                             inte_range) {
    tBegin= inte_range[1]
    tRef= inte_range[2]
    N_indiv= nrow(dose_mat)
    
    # true values
    # PK param
    V= paramLst_pkpop$V
    sd_lV= paramLst_pkpop$sd_lV
    k= paramLst_pkpop$k
    sd_lk= paramLst_pkpop$sd_lk
    # sd for conc. measurements in log scale
    a= paramLst_pkpop$a
    # sd for PD biomarker in log scale
    a2= paramLst_pkpop$a2
    
    # gen. 1 dataset
    Time= list()
    X= list()
    N= NULL
    V_vec= NULL
    k_vec= NULL
    
    for(i in 1: N_indiv) {
        time= x_timePoints
        Time[[i]]= sort(time)
        Vi= rlnorm(n= 1, meanlog= log(V), sdlog = sd_lV)
        ki= rlnorm(n= 1, meanlog= log(k), sdlog= sd_lk)
        
        fi= pkConc.1cpt(time= Time[[i]], 
                    dose= dose_mat[i,],
                    log.psii= log(c(Vi, ki)) )
        X[[i]]= rlnorm(n= length(x_timePoints), meanlog= log(fi), 
                       sdlog = a)
        N[i]= length(X[[i]])
        V_vec[i]= Vi
        k_vec[i]= ki
    }
    
    # PD
    eta_vec= NULL
    p_vec= NULL
    Y_vec= NULL
    z_mat= NULL
    N_z= NULL
    Time_z= list()
    psii_mat= matrix(NA, nrow= N_indiv, ncol= 2)
    
    for(i in 1: N_indiv) {
        Time_z[[i]]= z_timePoints
        log_psii= log(c(V_vec[i], k_vec[i]))
        eff_i= sapply(1:length(z_timePoints), function(k) {
            integrand.1co.5pl(x= z_timePoints[k], 
                              log.psii= log_psii, 
                              betas= pd_param, 
                              dose= dose_mat[i,])
        })
        eta_vec[i]= integral(fun= integrand.1co.5pl, 
                             xmin= tBegin, xmax= tRef,
                             log.psii= log_psii, 
                             dose= dose_mat[i,],
                             betas= pd_param)
        p_vec[i]= 1- exp(- eta_vec[i])
        Y_vec[i]= rbinom(n= 1, size= 1, prob= p_vec[i])
        z_mat= rbind(z_mat, 
                     rlnorm(n= length(z_timePoints), 
                            meanlog= log(eff_i), sdlog= a2) )
        psii_mat[i, ]= exp(log_psii)
        N_z[i]= ncol(z_mat)
    }
    # Time, X are lists, N, y are vectors
    lst= list(Time_x= Time, X= X, N= N, y= Y_vec, z_mat= z_mat,
              Time_z= Time_z, N_z= N_z,
              dose_mat= dose_mat,
              psii_mat= psii_mat,
              eta_vec= eta_vec)
    return (lst)
}


# a function to append new cohort data into existing data
# Time, X are lists, N, y are vectors
combine_data= function(dataLst, newdataLst) {
    n= length(newdataLst$Time_x)
    nExisting= length(dataLst$Time_x)
    # append to existing data
    for(i in 1: n) {
        dataLst$Time_x[[nExisting+ i]]= newdataLst$Time_x[[i]]
        dataLst$Time_z[[nExisting+ i]]= newdataLst$Time_z[[i]]
        dataLst$X[[nExisting+ i]]= newdataLst$X[[i]]
        dataLst$N[nExisting+ i]= newdataLst$N[i]
        dataLst$N_z[nExisting+ i]= newdataLst$N_z[i]
        dataLst$y[nExisting+ i]= newdataLst$y[i]
        dataLst$z_mat= rbind(dataLst$z_mat, 
                             newdataLst$z_mat[i,])
        dataLst$dose_mat= rbind(dataLst$dose_mat, 
                                newdataLst$dose_mat[i,])
        dataLst$psii_mat= rbind(dataLst$psii_mat, 
                                newdataLst$psii_mat[i,])
        dataLst$eta_vec[nExisting+i]= newdataLst$eta_vec[i] 
    }
    return(dataLst)
}



# safe rule, evaluated for dose (kappa_star)
# unsafe if Pr(pi>phi) >= ksi
calcEmpProp= function(pi_vec, targetProb) {
    # pi_vec contains samples of avg tox prob for a dose
    return(mean(pi_vec > targetProb))
}

# safe= 1, unsafe= 0
isSafe= function(pi_vec, targetProb, ksi) {
    safeFlag= 1
    empProp= calcEmpProp(pi_vec= pi_vec, targetProb= targetProb)
    
    # when the dose is not safe
    if(empProp > ksi) {
        safeFlag= 0
    }
    return(safeFlag) 
}



# a func to find optimal safe dose for next incoming cohort
# using all cumulative events up to the current cohort
# in the interim, explore all doses regardless of safety constraint
# which is equivalent to ksi=1
findOptDoseIdx= function(currDoseIdx, piMat, y,
                         targetProb, ksi= 1, triedDoseVec) {
    maxDoseLevel= ncol(piMat)
    
    # check for each dose whether they are safe
    doseSafeFlag_vec= sapply(c(1: ncol(piMat)), function(x) {
        isSafe(pi_vec= piMat[,x],
               targetProb=targetProb, ksi= ksi)
    })
    
    # double average, avg of avg tox prob at pop level
    pi_vec= colMeans(piMat)
    
    # (1) if all tried doses appear to be very safe, use fast escalation 
    if(sum(y)== 0) {
        recomDoseIdx= currDoseIdx+ 1
        # limit to available doses
        if(recomDoseIdx> maxDoseLevel) {
            recomDoseIdx= maxDoseLevel
        }
    }
    # (2) if there are events, find closest safe dose w/o skipping
    # according to estimated tox prob
    else {
        # dose levels that are safe
        safeDoseIdx= which(doseSafeFlag_vec==1)
        ## (a) if there is no safe dose
        if(length(safeDoseIdx)== 0) {
            recomDoseIdx= 0
        }
        ## (b) if there is at least 1 safe dose
        else if(length(safeDoseIdx) > 0) {
            # determine opt doses closest to targetProb among safe doses
            optDoseIdx= which.min(abs(pi_vec[safeDoseIdx]-targetProb) )
            
            # assign next dose, w/o skipping doses
            recomDoseIdx= optDoseIdx
            # index of highest tried dose
            highestTriedIdx= sum(triedDoseVec)
            print(paste("highestTriedIdx=", highestTriedIdx,
                        " recomDoseIdx=", recomDoseIdx))
            if(recomDoseIdx> highestTriedIdx) {
                recomDoseIdx= highestTriedIdx+ 1
            }
        }
    } # end of outside else block
    return(recomDoseIdx)
}

# a func. to find MTD
determineMTD2= function(piMat, targetProb=0.3, ksi, maxDoseLevel) {
    # maintain matrix format if max dose level is 1
    piMat= piMat[,1:maxDoseLevel,drop=F]
    numDoses= ncol(piMat)
    
    # check which doses are safe, will return a vector of T/F
    safeDoseIdx= sapply(1:numDoses, function(x) {
        isSafe(pi_vec=piMat[,x], targetProb=targetProb, ksi=ksi)
    }) 
    #print(safeDoseIdx)
    safeDoses= c(1:numDoses)[safeDoseIdx== 1]
    
    # (1) when there are no safe doses (all doses are toxic)
    if(sum(safeDoseIdx)== 0) {
        # return nonconclusive MTD index
        return(0)
    }
    # (2) when there are several safe doses
    else if(sum(safeDoseIdx)> 0){
        # a. multiple safe doses exist
        if(length(safeDoses)> 1) {
            # the vector of avg DLT prob for safe doses
            avg_pi= colMeans(piMat[,safeDoses])
            MTDIdx= which.min(abs(avg_pi- targetProb))
            return(MTDIdx)
        }
        # b. only one safe dose exists
        else if(length(safeDoses)== 1) {
            return(safeDoses)
        }
    }
}


# simulate data for 1 trial (using optimal dose rule)
# T0 is the infusion end time (real type)
# doseVec provides the doses to explore
run_1_trial_2cpt= function(cohortSize=3, 
                           maxNum= 30,
                           paramLst_pkpop, 
                           pd_param_5pl,
                           x_timePoints,
                           z_timePoints,
                           inte_range, 
                           T0, doseVec,
                           S, nBurnin, thin=10, nchain=3,
                           targetProb=0.3, ksi, 
                           B=200, 
                           scen, nSim, path, to_plot) {
    # max num of cohorts for a simulated trial
    max_nCohorts= maxNum/ cohortSize
    # num of doses
    maxDoseLevel= length(doseVec)
    
    # samples to be drawn for each PKPOP and PD params
    #B= 500
    # store post. samples of average tox. prob. 
    # (as func of PKPOP and PD params) at diff doses
    piMat= matrix(NA, nrow= (S-nBurnin)/thin, ncol= maxDoseLevel)
    # for each incoming cohort, store the following info:
    # avg tox prob at each dose 
    #mat1= matrix(NA, nrow= max_nCohorts, ncol= 6+length(doseVec))
    mat1= NULL
    # PKPOP and PD param estimates 
    #mat2= matrix(NA, nrow= max_nCohorts, ncol= 12)
    mat2= NULL
    # dose safety matrix, Pr(pi>p_T) for each dose 
    mat3= NULL
    # toxicity outcome wrt dose level
    y_mat= NULL
    # matrix of tried doses
    triedDose_mat= NULL
    # 1 = tried, 0 = untried
    triedDoseVec= rep(0, maxDoseLevel)
    # matrix for Rhat
    RhatMat= NULL
    
    # current dose index, beginning from the lowest
    doseIdx= 1
    # cum. data list
    cum_datLst= NULL
    # cumulative number of patients in study
    cumNum= 0
    # flag variable for safety rules
    contiFlag= 1
    
    while(contiFlag== 1 & cumNum< maxNum) {
        currDose= doseVec[doseIdx]
        # update tried doses vector
        triedDoseVec[doseIdx]= 1
        print("dose level tried:")
        print(triedDoseVec)
        triedDose_mat= rbind(triedDose_mat, triedDoseVec)
        
        # enroll a cohort of patients to treat at currDose
        curr_datLst= simu_pkpd_5pl_1cht(
            paramLst_pkpop= paramLst_pkpop, 
            pd_param= pd_param_5pl,
            x_timePoints= x_timePoints,
            z_timePoints= z_timePoints,
            dose_mat= cbind(rep(T0,cohortSize),
                            rep(currDose,cohortSize)), 
            inte_range= inte_range)
        # append new data to existing data
        cum_datLst= combine_data(dataLst=cum_datLst, 
                                 newdataLst= curr_datLst)
        # update num of patients in study
        cumNum= cumNum+ cohortSize
        
        dat1= list(N_indiv= length(cum_datLst$y),
                   nTimePoints= length(x_timePoints),
                   Time_x=matrix(unlist(cum_datLst$Time_x), 
                                 ncol=length(x_timePoints),byrow=T),
                   X= matrix(unlist(cum_datLst$X),ncol=length(x_timePoints),
                             byrow=T),
                   dose_vec= cum_datLst$dose_mat[,2],T0= T0, 
                   y= cum_datLst$y, 
                   inte_range=inte_range)
        
        print(table(cum_datLst$y))
        
        mod_fit= sampling(object= mod, data = dat1, iter = S, 
                          warmup= nBurnin, chains= nchain, 
                          verbose = FALSE, thin= thin,
                          cores = getOption("mc.cores", 1L) )
        print(mod_fit, pars = to_plot, digits= 3)
        
        postLst= extract(mod_fit,to_plot)
        postMat= cbind(postLst$Vpop, postLst$alphapop, 
                       postLst$betapop,postLst$k21pop,
                       postLst$sd_lVi,postLst$sd_lalphai,
                       postLst$sd_lbetai,postLst$sd_lk21i,
                       postLst$Emax,postLst$ED50,postLst$gamma, 
                       postLst$a)
        
        # make plots
        pathName= paste(path,"scen",scen,"_traces_sim", nSim, 
                        "_",cumNum/cohortSize, ".pdf", sep= '')
        
        if(nSim %% 50 == 0) {
            pdf(file= pathName)
            { 
                print(traceplot(mod_fit, pars = to_plot))
            }
            dev.off()
        }
        
        piMat= sapply(1:maxDoseLevel, function(x) {
            post_pi_atDoseStar(dose_star= doseVec[x],T0=T0, 
                               post_mat= postMat,
                               inte_range= inte_range, B=B)
        })
	piMat= piMat[complete.cases(piMat),]        

        mat3_row_i= sapply(c(1:maxDoseLevel), function(x) {
            calcEmpProp(pi_vec= piMat[,x], targetProb=targetProb)
        })
        
        recom_doseIdx=findOptDoseIdx(currDoseIdx= doseIdx, piMat= piMat, 
                                     y= cum_datLst$y, targetProb= targetProb, ksi= 1,
                                     triedDoseVec= triedDoseVec)
        
        # contiFlag= 1 if there is at least 1 safe dose (the first), 
        # to end trial early otherwise
        contiFlag= isSafe(pi_vec= piMat[,1],
                          targetProb= targetProb, ksi= ksi)
        if(contiFlag== 0) {recom_doseIdx= 0}
        
        #mat1[cumNum/cohortSize,]= c(cumNum, contiFlag, doseIdx,colMeans(piMat), piiandpip1,recom_doseIdx)
        mat1= rbind(mat1, 
                    c(cumNum, contiFlag, doseIdx,
                      colMeans(piMat), 
                      recom_doseIdx, 
                      sum(curr_datLst$y), cohortSize))
        y_mat_row_i= mat1[cumNum/cohortSize, c(3,10)]
        
        # put down estimates of PKPOP and PD params
        #mat2[cumNum/cohortSize,]= colMeans(postMat)
        mat2= rbind(mat2, colMeans(postMat))
        
        mat3= rbind(mat3, mat3_row_i)
        
        y_mat= rbind(y_mat, y_mat_row_i)
        RhatMat= rbind(RhatMat, 
                       summary(mod_fit,pars=to_plot)$summary[,"Rhat"])
        
        print("Roundwise pi,dose recommendations and num events:")
        print(round(mat1[c(1:(cumNum/cohortSize)),],3))
        print("Roundwise post. mean of PKPD parameters:")
        print(round(mat2[c(1:(cumNum/cohortSize)),],3))
        print("Roundwise safety prob. matrix for each dose")
        print(round(mat3[c(1:(cumNum/cohortSize)),],3))
        print("Roundwise events at tried doses:")
        print(t(sapply(by(y_mat,y_mat[,1], colSums),identity))[,2])
        
        # update dose assignment for next cohort
        doseIdx= recom_doseIdx
        
    } # end of while loop
    
    nEvent= sum(cum_datLst$y)
    doseTrt= as.vector(table(factor(mat1[,3], levels= 1:maxDoseLevel)))
    #MTD= determineMTD2(piMat=piMat, targetProb=targetProb, ksi=ksi, maxDoseLevel= maxDoseLevel) 
    MTD= findOptDoseIdx(currDoseIdx= doseIdx, piMat= piMat, 
                        y= cum_datLst$y, targetProb= targetProb, ksi= ksi,
                        triedDoseVec= triedDoseVec)
    # when MTD is among the doses
    if(MTD> 0) {
        MTDProb= mean(piMat[,MTD])
    }
    # when a trial is ended earlier => inconclusive MTD
    else if(MTD== 0) {
        #MTDProb= colMeans(piMat)[1]
        MTDProb= NA
    }
    return(list(mat1= mat1, mat2= mat2, mat3= mat3, y_mat= y_mat,
                nEvent= nEvent, nPts= cumNum,
                MTD= MTD,
                MTDProb= MTDProb,
                res=cohortSize* doseTrt,
                triedDose_mat= triedDose_mat,
                RhatMat= RhatMat, piMat= piMat))
}


