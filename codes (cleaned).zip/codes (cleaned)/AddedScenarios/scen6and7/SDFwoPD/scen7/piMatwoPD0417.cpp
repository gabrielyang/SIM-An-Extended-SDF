// Apr 17 2022
// cpp script for calc. posterior sample for doseStar
// working models: 2-cpt IV infusion PK + sigmoid Emax PD models with 1-param link function

# include <Rcpp.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppNumerical)]]
#define EIGEN_PERMANENTLY_DISABLE_STUPID_WARNINGS
#include <Eigen/Eigen>
#include <RcppNumerical.h>



// this is a scalar func. (a scalar will be returned)
// time is a vector of time points
// psi is a 4-dim. vector
// dose is a 2-dim. vector, infusion time and dosage
// T0 and D are fixed/ given
double pk_conc_scalar(const double time, 
                      const double dose,
                      const double T0,
                      const NumericVector log_psi) {
    NumericVector psi= exp(log_psi);
    double V, alpha, beta, k21;
    V= psi[0]; 
    alpha= psi[1];
    beta= psi[2];
    k21= psi[3];
    double conc; 
    
    if(time<= T0) {
        conc= ( (alpha-k21)/alpha/(alpha- beta)*(1- exp(-alpha* time))+
                (beta-k21)/beta/(beta- alpha)* (1- exp(-beta* time)) );
    }
    else {
        conc= ( (alpha-k21)/alpha/(alpha- beta)*
            (exp(-alpha*(time-T0))- exp(-alpha* time))+
        (beta-k21)/beta/(beta- alpha)* (exp(-beta*(time- T0))- exp(-beta* time)) );
    }
    return dose/V/T0* conc ;
}


// dose_params= (T0, D), pd_params= (Emax, ED50, gamma)
class pk_integrand: public Numer::Func {
private:
    double dose_i, T0;
    NumericVector log_psii;
    double Emax, ED50, gamma;
public:
    // note the format
    pk_integrand(double dose_i_,
                 double T0_,
                 NumericVector log_psii_,
                 double Emax_,
                 double ED50_,
                 double gamma_) : 
                 dose_i(dose_i_), 
                 T0(T0_),
                 log_psii(log_psii_), 
                 Emax(Emax_),
                 ED50(ED50_),
                 gamma(gamma_) {}
    // &x is the variable to be integrated over
    double operator()(const double & x) const {
        double conc= pk_conc_scalar(x, dose_i, T0, log_psii);
        return Emax* pow(conc, gamma)/(pow(ED50, gamma)+ pow(conc, gamma));
    }
};


// [[Rcpp::export]]
NumericVector computeEta(const double &dose_i,
                         const double &T0,
                         const NumericVector &log_psii,
                         const double &Emax,
                         const double &ED50,
                         const double &gamma,
                         const double &lower, 
                         const double &upper) {
    // make sure the args are in the correct order for function
    pk_integrand fun(dose_i, T0, log_psii, Emax, ED50, gamma);
    double err_est;
    int err_code;
    const double result = Numer::integrate(fun, lower, upper, err_est, err_code,
                          6, 1e-4, 1e-2, Numer::Integrator<double>::GaussKronrod15);
    return NumericVector::create(Named("result") = result,
                                 Named("error") = err_est);
}



// a func. to draw post. samples of avg tox. prob. at population level 
// (for a post. sample of theta_pkpop and theta_pd)
// by integrating-out random effects

//[[Rcpp::export()]]
NumericVector post_pi_atDoseStar(const double dose_star,
                                 const double T0,
                                 const NumericMatrix post_mat, 
                                 const NumericVector inte_range,
                                 const int B) {
    // number of post. samples for pkpop and pd parameters
    int S= post_mat.rows();
    NumericVector pi_vec (S);
    // B= number of samples of random effects to draw for each row of post. samples
    NumericVector log_Vi_vec (B), log_alphai_vec (B), log_betai_vec (B), log_k21i_vec (B);
    double Emax, ED50, gamma; 
    double log_betai,  log_k21i;
    const double t_begin= inte_range[0], t_ref= inte_range[1];
    int s;

    for(s= 0; s < S; s++) {
        // mean= log_V_pop, sd= sqrt(1.0/gamma1)
        log_Vi_vec= log( rlnorm(B, log(post_mat(s,0)), post_mat(s,4)) );
        // mean= log_alpha_pop, sd= sqrt(1.0/gamma2)
        log_alphai_vec= log( rlnorm(B, log(post_mat(s,1)), post_mat(s,5)) );
        // mean= log_beta_pop, sd= sqrt(1.0/gamma3)
        log_betai_vec= log( rlnorm(B, log(post_mat(s,2)), post_mat(s,6)) );
        // mean= log_k21_pop, sd= sqrt(1.0/gamma4)
        log_k21i_vec= log( rlnorm(B, log(post_mat(s,3)), post_mat(s,7)) );
        
        Emax= post_mat(s,8);
        ED50= post_mat(s,9);
        gamma= post_mat(s,10);
        NumericVector eta_vec (B), pii_vec (B);

        for(int b= 0; b < B; b++) {
	     while(log_k21i_vec[b] <= log_betai_vec[b] ) {
                log_betai= log( rlnorm(1, log(post_mat(s,2)), post_mat(s,6))[0] );
                log_k21i= log( rlnorm(1, log(post_mat(s,3)), post_mat(s,7))[0] );
                log_betai_vec[b]= log_betai;
                log_k21i_vec[b]= log_k21i;
            }

            NumericVector log_psii= NumericVector::create(log_Vi_vec[b], log_alphai_vec[b],
                                                          log_betai_vec[b], log_k21i_vec[b]);
            eta_vec[b]= computeEta(dose_star, T0, log_psii, Emax, ED50, gamma, t_begin, t_ref)[0];
            pii_vec[b]= 1- exp(- 1 * eta_vec[b]);
        }
        // integrate out psii for each post. sample of pkpop and pd params. 
        pi_vec[s]= sum(pii_vec)/ pii_vec.length();
    }
    return pi_vec; 
}




