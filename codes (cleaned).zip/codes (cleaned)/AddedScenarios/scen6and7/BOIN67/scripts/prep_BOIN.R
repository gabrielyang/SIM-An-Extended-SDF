# May 2 2023
# prep scripts for BOIN design
# scenarios 6 to 10
# scen 6 to 7: 2 models misspec
# scen 8 to 10: 3 models misspec

##########################################
# BOIN design
library(BOIN)

temp= get.boundary(target=0.3, ncohort=10, 
                   cohortsize=3, n.earlystop=100, 
                   p.saf=0.18, p.tox=0.42, 
                   cutoff.eli=0.95, extrasafe=F)


library(pracma)


# 1-cpt single dose IV infusion model
pkConc.1cpt= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  k= psi[2]
  
  res1= D/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= D/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}


# functions to simulate data (the 5-PL PD model)
integrand.1co.5pl= function(x, log.psii, betas, dose) {
  beta1= betas[1]
  beta2= betas[2]
  beta3= betas[3]
  beta4= betas[4]
  beta5= betas[5]
  
  conc= pkConc.1cpt(time= x, dose= dose, log.psii= log.psii) 
  res= beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
  return(res)
}

# data generation: fixed link function
link.1co.5pl= function(dose, log.psii, betas, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  eta= integral(fun= integrand.1co.5pl, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii,
                betas= betas)  
  return(1- exp(-eta))
}





# data generation model: 2-cpt PK + 5-PL PD models+ fixed link func.
simu_pkpd_5pl_1cht= function(paramLst_pkpop, 
                             pd_param,
                             x_timePoints,
                             z_timePoints,
                             dose_mat, 
                             inte_range) {
    tBegin= inte_range[1]
    tRef= inte_range[2]
    N_indiv= nrow(dose_mat)
    
    # true values
    # PK param
    V= paramLst_pkpop$V
    sd_lV= paramLst_pkpop$sd_lV
    k= paramLst_pkpop$k
    sd_lk= paramLst_pkpop$sd_lk
    # sd for conc. measurements in log scale
    a= paramLst_pkpop$a
    # sd for PD biomarker in log scale
    a2= paramLst_pkpop$a2
    
    # gen. 1 dataset
    Time= list()
    X= list()
    N= NULL
    V_vec= NULL
    k_vec= NULL
    
    for(i in 1: N_indiv) {
        time= x_timePoints
        Time[[i]]= sort(time)
        Vi= rlnorm(n= 1, meanlog= log(V), sdlog = sd_lV)
        ki= rlnorm(n= 1, meanlog= log(k), sdlog= sd_lk)
        
        fi= pkConc.1cpt(time= Time[[i]], 
                    dose= dose_mat[i,],
                    log.psii= log(c(Vi, ki)) )
        X[[i]]= rlnorm(n= length(x_timePoints), meanlog= log(fi), 
                       sdlog = a)
        N[i]= length(X[[i]])
        V_vec[i]= Vi
        k_vec[i]= ki
    }
    
    # PD
    eta_vec= NULL
    p_vec= NULL
    Y_vec= NULL
    z_mat= NULL
    N_z= NULL
    Time_z= list()
    psii_mat= matrix(NA, nrow= N_indiv, ncol= 2)
    
    for(i in 1: N_indiv) {
        Time_z[[i]]= z_timePoints
        log_psii= log(c(V_vec[i], k_vec[i]))
        eff_i= sapply(1:length(z_timePoints), function(k) {
          integrand.1co.5pl(x= z_timePoints[k], 
                              log.psii= log_psii, 
                              betas= pd_param, 
                              dose= dose_mat[i,])
        })
        eta_vec[i]= integral(fun= integrand.1co.5pl, 
                             xmin= tBegin, xmax= tRef,
                             log.psii= log_psii, 
                             dose= dose_mat[i,],
                             betas= pd_param)
        p_vec[i]= 1- exp(- eta_vec[i])
        Y_vec[i]= rbinom(n= 1, size= 1, prob= p_vec[i])
        z_mat= rbind(z_mat, 
                     rlnorm(n= length(z_timePoints), 
                            meanlog= log(eff_i), sdlog= a2) )
        psii_mat[i, ]= exp(log_psii)
        N_z[i]= ncol(z_mat)
    }
    # Time, X are lists, N, y are vectors
    lst= list(Time_x= Time, X= X, N= N, y= Y_vec, z_mat= z_mat,
              Time_z= Time_z, N_z= N_z,
              dose_mat= dose_mat,
              psii_mat= psii_mat,
              eta_vec= eta_vec)
    return (lst)
}


# a func to return dose index/ level
convertToDoseIndex= function(dose, doseRef) {
    for(i in 1: length(doseRef)) {
        if(doseRef[i]== dose) { return(i) }
    } # end of for loop
}


# a function to append new cohort data into existing data
# Time, X are lists, N, y are vectors
combine_data= function(dataLst, newdataLst) {
    n= length(newdataLst$Time_x)
    nExisting= length(dataLst$Time_x)
    # append to existing data
    for(i in 1: n) {
        dataLst$Time_x[[nExisting+ i]]= newdataLst$Time_x[[i]]
        dataLst$Time_z[[nExisting+ i]]= newdataLst$Time_z[[i]]
        dataLst$X[[nExisting+ i]]= newdataLst$X[[i]]
        dataLst$N[nExisting+ i]= newdataLst$N[i]
        dataLst$N_z[nExisting+ i]= newdataLst$N_z[i]
        dataLst$y[nExisting+ i]= newdataLst$y[i]
        dataLst$z_mat= rbind(dataLst$z_mat, 
                             newdataLst$z_mat[i,])
        dataLst$dose_mat= rbind(dataLst$dose_mat, 
                                newdataLst$dose_mat[i,])
        dataLst$psii_mat= rbind(dataLst$psii_mat, 
                                newdataLst$psii_mat[i,])
        dataLst$eta_vec[nExisting+i]= newdataLst$eta_vec[i] 
    }
    return(dataLst)
}



run_1_trial_BOIN = function(cohortSize, 
                            maxNum,
                            paramLst_pkpop, 
                            pd_param_5pl,
                            x_timePoints,
                            z_timePoints,
                            inte_range, 
                            T0, doseVec,
                            targetProb,  
                            n.earlystop, startdose, 
                            p.saf, p.tox, 
                            cutoff.eli, extrasafe, 
                            offset) {
    
    if(is.null(p.saf)) { p.saf = 0.6 * targetProb }
    if(is.null(p.tox)) { p.tox = 1.4 * targetProb }
    nCohort= maxNum/cohortSize
    
    ndose = length(doseVec)
    npts = nCohort * cohortSize
    
    temp = get.boundary(target= targetProb, ncohort=nCohort, 
                        cohortsize=cohortSize, n.earlystop= n.earlystop, 
                        p.saf= p.saf, p.tox= p.tox, cutoff.eli, 
                        extrasafe= extrasafe)$boundary_tab
    # using numbers from tabulation table to decide 
    # escalate/deescalate/stay or eliminate at each round
    b.e = temp[2, ]
    b.d = temp[3, ]
    b.elim = temp[4, ]
    
    cum_datLst= NULL
    y = rep(0, ndose)
    n = rep(0, ndose)
    earlystop = 0
    d = startdose
    elimi = rep(0, ndose)
    
    for (i in 1: nCohort) {
        #############Sample new data################
        # get dosage for a dose level
        currDose= doseVec[d]
        # enroll a cohort of patients to treat at currDose
        curr_datLst= simu_pkpd_5pl_1cht(
            paramLst_pkpop=paramLst_pkpop, 
            pd_param= pd_param_5pl,
            x_timePoints= x_timePoints,
            z_timePoints= z_timePoints,
            dose_mat=cbind(rep(T0, cohortSize), 
                           rep(currDose, cohortSize)), 
            inte_range= inte_range)
        
        # append new data to existing data
        cum_datLst= combine_data(dataLst=cum_datLst, 
                                 newdataLst= curr_datLst)
        
        y[d]= y[d]+ sum(curr_datLst$y)
        n[d]= n[d]+ cohortSize
        # find the index number in the tabulation table
        # coresponding to row 1 in temp$boundary_tab
        idx= which(seq(from= cohortSize, to=maxNum,
                       by= cohortSize)== n[d])
        
        # dose allocation is found using tabulation table at the current
        # dose
        if (n[d] >= n.earlystop) 
            break
        if (!is.na(b.elim[idx])) {
            if (y[d] >= b.elim[idx]) {
                elimi[d:ndose] = 1
                if (d == 1) {
                    earlystop = 1
                    break
                }
            }
            if (extrasafe== T) {
                if (d == 1 && n[1] >= 3) {
                    if (1 - pbeta(targetProb, 
                                  1+ y[1], 1+ n[1] - y[1]) > 
                        cutoff.eli - offset) {
                        earlystop = 1
                        break
                    }
                }
            }
        }
        if (y[d] <= b.e[idx] && d != ndose) {
            if (elimi[d + 1] == 0) 
                d = d + 1
        }
        else if (y[d] >= b.d[idx] && d != 1) {
            d = d - 1
        }
        else {
            d = d
        }
    }
    
    if (earlystop == 1) {
        MTD = 0
    }
    else {
        MTD = select.mtd(target= targetProb, 
                         npts= n, ntox= y, 
                         cutoff.eli= cutoff.eli, 
                         extrasafe=extrasafe, offset= offset)$MTD
    }
    return(list(MTD= MTD, mat= cbind(y, n),
                res= n))
    
}

run_BOIN_sim= function(cohortSize=3, 
                       maxNum= 30,
                       paramLst_pkpop, 
                       pd_param_5pl,
                       x_timePoints,
                       z_timePoints,
                       inte_range, 
                       T0, doseVec,
                       targetProb=0.3,  
                       n.earlystop = 100, startdose = 1, 
                       p.saf= NULL, p.tox = NULL, 
                       cutoff.eli = 0.95, extrasafe = FALSE, 
                       offset= 0.05, nSim) {
    MTD_vec= NULL
    res_mat= NULL 
    totalNum_vec= NULL
    eventNum_vec= NULL
    
    for(nsim in 1: nSim) {
        out= run_1_trial_BOIN(cohortSize= cohortSize, 
                              maxNum= maxNum,
                              paramLst_pkpop= paramLst_pkpop, 
                              pd_param_5pl= pd_param_5pl,
                              x_timePoints= x_timePoints,
                              z_timePoints= z_timePoints,
                              inte_range= inte_range, 
                              T0=T0, doseVec= doseVec,
                              targetProb= targetProb,  
                              n.earlystop= n.earlystop, startdose= startdose, 
                              p.saf= p.saf, p.tox= p.tox, 
                              cutoff.eli= cutoff.eli, extrasafe= extrasafe, 
                              offset= offset)    
        MTD_vec[nsim]= out$MTD
        eventNum_vec[nsim]= sum(out$mat[,1])
        totalNum_vec[nsim]= sum(out$mat[,2])
        res_mat= rbind(res_mat, out$res)
    }
    
    return(list(selProb= table(MTD_vec)/nSim,
                avgPtsAllo= colSums(res_mat)/nSim,
                avgtotalPts= mean(totalNum_vec),
                avgEventNum= mean(eventNum_vec),
                avgToxProb= sum(eventNum_vec)/ sum(totalNum_vec) ))
}