# May 23 2022
# script for making box plots (posterior mean of p_i) for 2-cpt models
# comparing 2cpt-SMDF and CRMs

getToxProb= function(lst, numDoseLevel= 5) {
    N= length(lst)
    MTDidx_vec= NULL
    toxEstMat= matrix(NA, nrow= N, ncol= numDoseLevel)
    
    for(i in 1: N) {
        MTDidx_vec[i]= lst[[i]]$MTD
        if(MTDidx_vec[i] != 0) {
            toxEstMat[i, ]= lst[[i]]$mat1[nrow(lst[[i]]$mat1),c(4:8)]
        }
    }
    return(toxEstMat)
}

library(ggplot2)
library(reshape2)
library(data.table)


truth.sc1= c(0.01, 0.06, 0.18, 0.31, 0.51)
truth.sc2= c(0.16, 0.29, 0.40, 0.48, 0.59)
truth.sc3= c(0.05, 0.10, 0.16, 0.21, 0.29)
truth.sc4= c(0.07, 0.18, 0.30, 0.40, 0.54)


# scen 1
#setwd("C:/Users/cyang8/Reseraches/PKPD2/runTrial0926/resultDatasets/sim_1k/wPD04_10pct/scen1")
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen1")
#setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets1/sim1k_05_0pct/scen1")


idx= c(1:1000)

length(idx)

scen= 1
count= 0

lst1= NULL
for(i in idx) {
    count= count+ 1
    lst1[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat1= getToxProb(lst= lst1, numDoseLevel= 5)
toxProbMat1.CRM1= readRDS(file= "scen1_res_CRM1.rds")$toxProbMat
toxProbMat1.CRM2= readRDS(file= "scen1_res_CRM2.rds")$toxProbMat


setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_3/scen1")

scen= 1
count= 0

lst1.wo= NULL
for(i in idx) {
  count= count+ 1
  lst1.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat1.wo= getToxProb(lst= lst1.wo, numDoseLevel= 5)


plot_sc1_smdf = reshape2::melt(toxProbMat1)
names(plot_sc1_smdf)= c("sampNum", "dose", "toxProb")
plot_sc1_smdf$design= rep("SDF-wPD", nrow(plot_sc1_smdf))
plot_sc1_smdf$dose= as.factor(plot_sc1_smdf$dose)

plot_sc1_crm1 = reshape2::melt(toxProbMat1.CRM1)
names(plot_sc1_crm1)= c("sampNum", "dose", "toxProb")
plot_sc1_crm1$design= rep("CRM1", nrow(plot_sc1_crm1))
plot_sc1_crm1$dose= as.factor(plot_sc1_crm1$dose)

plot_sc1_crm2 = reshape2::melt(toxProbMat1.CRM2)
names(plot_sc1_crm2)= c("sampNum", "dose", "toxProb")
plot_sc1_crm2$design= rep("CRM2", nrow(plot_sc1_crm2))
plot_sc1_crm2$dose= as.factor(plot_sc1_crm2$dose)

plot_sc1_smdfwo = reshape2::melt(toxProbMat1.wo)
names(plot_sc1_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc1_smdfwo$design= rep("SDF-woPD", nrow(plot_sc1_smdfwo))
plot_sc1_smdfwo$dose= as.factor(plot_sc1_smdfwo$dose)

plot_sc1_comb= rbind(plot_sc1_smdf, plot_sc1_crm1, plot_sc1_crm2,
                     plot_sc1_smdfwo)
#plot_sc1_comb= rbind(plot_sc1_smdf, plot_sc1_crm1)
plot_sc1_comb$design= as.factor(plot_sc1_comb$design)


#true_sc1_df= data.frame(dose= 1:5, toxProb= c(0.005, 0.048, 0.161, 0.289, 0.509))
#true_sc1_df= data.frame(dose= 1:5, toxProb= c(0.008, 0.054, 0.165, 0.292, 0.516))
true_sc1_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc1)

d.sc1= data.table(x= true_sc1_df$dose, y=true_sc1_df$toxProb)


p1 <- ggplot() + 
    geom_boxplot(data=plot_sc1_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 1",
         x="dose level", y = "DLT prob.")+
    geom_line(data= true_sc1_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc1, aes(x= x, y= y),
               shape= c(2,2,2,17,2), size= 3)
p1

# scen 2
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen2")
#setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets1/sim1k_05_0pct/scen2")

idx= c(1:1000)

scen= 2
count= 0

lst2= NULL
for(i in idx) {
    count= count+ 1
    lst2[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat2= getToxProb(lst= lst2, numDoseLevel= 5)
toxProbMat2= toxProbMat2[complete.cases(toxProbMat2), ]

toxProbMat2.CRM1= readRDS(file= "scen2_res_CRM1.rds")$toxProbMat
toxProbMat2.CRM1= toxProbMat2.CRM1[complete.cases(toxProbMat2.CRM1), ]

toxProbMat2.CRM2= readRDS(file= "scen2_res_CRM2.rds")$toxProbMat
toxProbMat2.CRM2= toxProbMat2.CRM2[complete.cases(toxProbMat2.CRM2), ]


setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_3/scen2")

scen= 2
count= 0

lst2.wo= NULL
for(i in idx) {
  count= count+ 1
  lst2.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat2.wo= getToxProb(lst= lst2.wo, numDoseLevel= 5)
toxProbMat2.wo= toxProbMat2.wo[complete.cases(toxProbMat2.wo), ]


plot_sc2_smdf = reshape2::melt(toxProbMat2)
names(plot_sc2_smdf)= c("sampNum", "dose", "toxProb")
plot_sc2_smdf$design= rep("SDF-wPD", nrow(plot_sc2_smdf))
plot_sc2_smdf$dose= as.factor(plot_sc2_smdf$dose)

plot_sc2_crm1 = reshape2::melt(toxProbMat2.CRM1)
names(plot_sc2_crm1)= c("sampNum", "dose", "toxProb")
plot_sc2_crm1$design= rep("CRM1", nrow(plot_sc2_crm1))
plot_sc2_crm1$dose= as.factor(plot_sc2_crm1$dose)

plot_sc2_crm2 = reshape2::melt(toxProbMat2.CRM2)
names(plot_sc2_crm2)= c("sampNum", "dose", "toxProb")
plot_sc2_crm2$design= rep("CRM2", nrow(plot_sc2_crm2))
plot_sc2_crm2$dose= as.factor(plot_sc2_crm2$dose)

plot_sc2_smdfwo = reshape2::melt(toxProbMat2.wo)
names(plot_sc2_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc2_smdfwo$design= rep("SDF-woPD", nrow(plot_sc2_smdfwo))
plot_sc2_smdfwo$dose= as.factor(plot_sc2_smdfwo$dose)

plot_sc2_comb= rbind(plot_sc2_smdf, plot_sc2_crm1, plot_sc2_crm2,
                     plot_sc2_smdfwo)
plot_sc2_comb$design= as.factor(plot_sc2_comb$design)

#true_sc2_df= data.frame(dose= 1:5, toxProb= c(0.162, 0.289, 0.403, 0.482, 0.589))
#true_sc2_df= data.frame(dose= 1:5, toxProb= c(0.162, 0.290, 0.405, 0.483, 0.591))
true_sc2_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc2)
d.sc2= data.table(x= true_sc2_df$dose, y=true_sc2_df$toxProb)


p2 <- ggplot() + 
    geom_boxplot(data= plot_sc2_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 2",
         x="dose level", y = "DLT prob.")+ 
    geom_line(data= true_sc2_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc2, aes(x= x, y= y),
               shape= c(2,17,2,2,2), size= 3)
p2


# scen 3
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen3")
#setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets1/sim1k_05_0pct/scen3")

idx= c(1:1000)
length(idx)

scen= 3
count= 0

lst3= NULL
for(i in idx) {
    count= count+ 1
    lst3[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat3= getToxProb(lst= lst3, numDoseLevel= 5)
toxProbMat3= toxProbMat3[complete.cases(toxProbMat3), ]

toxProbMat3.CRM1= readRDS(file= "scen3_res_CRM1.rds")$toxProbMat
toxProbMat3.CRM1= toxProbMat3.CRM1[complete.cases(toxProbMat3.CRM1), ]

toxProbMat3.CRM2= readRDS(file= "scen3_res_CRM2.rds")$toxProbMat
toxProbMat3.CRM2= toxProbMat3.CRM2[complete.cases(toxProbMat3.CRM2), ]

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_3/scen3")

scen= 3
count= 0

lst3.wo= NULL
for(i in idx) {
  count= count+ 1
  lst3.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat3.wo= getToxProb(lst= lst3.wo, numDoseLevel= 5)
toxProbMat3.wo= toxProbMat3.wo[complete.cases(toxProbMat3.wo), ]

plot_sc3_smdf = reshape2::melt(toxProbMat3)
names(plot_sc3_smdf)= c("sampNum", "dose", "toxProb")
plot_sc3_smdf$design= rep("SDF-wPD", nrow(plot_sc3_smdf))
plot_sc3_smdf$dose= as.factor(plot_sc3_smdf$dose)

plot_sc3_crm1 = reshape2::melt(toxProbMat3.CRM1)
names(plot_sc3_crm1)= c("sampNum", "dose", "toxProb")
plot_sc3_crm1$design= rep("CRM1", nrow(plot_sc3_crm1))
plot_sc3_crm1$dose= as.factor(plot_sc3_crm1$dose)

plot_sc3_crm2 = reshape2::melt(toxProbMat3.CRM2)
names(plot_sc3_crm2)= c("sampNum", "dose", "toxProb")
plot_sc3_crm2$design= rep("CRM2", nrow(plot_sc3_crm2))
plot_sc3_crm2$dose= as.factor(plot_sc3_crm2$dose)

plot_sc3_smdfwo = reshape2::melt(toxProbMat3.wo)
names(plot_sc3_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc3_smdfwo$design= rep("SDF-woPD", nrow(plot_sc3_smdfwo))
plot_sc3_smdfwo$dose= as.factor(plot_sc3_smdfwo$dose)


plot_sc3_comb= rbind(plot_sc3_smdf, plot_sc3_crm1, plot_sc3_crm2,
                     plot_sc3_smdfwo)
plot_sc3_comb$design= as.factor(plot_sc3_comb$design)

#true_sc3_df= data.frame(dose= 1:5, toxProb= c(0.044, 0.097, 0.157, 0.206, 0.282))
true_sc3_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc3)
d.sc3= data.table(x= true_sc3_df$dose, y=true_sc3_df$toxProb)


p3 <- ggplot() + 
    geom_boxplot(data= plot_sc3_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 3",
         x="dose level", y = "DLT prob.")+ 
    geom_line(data= true_sc3_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc3, aes(x= x, y= y),
               shape= c(2,2,2,2,17), size= 3)
p3

# scen 4
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen4")
#setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets1/sim1k_05_0pct/scen4")

idx= c(1:1000)
length(idx)

scen= 4
count= 0

lst4= NULL
for(i in idx) {
    count= count+ 1
    lst4[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

toxProbMat4= getToxProb(lst= lst4, numDoseLevel= 5)
toxProbMat4= toxProbMat4[complete.cases(toxProbMat4), ]

toxProbMat4.CRM1= readRDS(file= "scen4_res_CRM1.rds")$toxProbMat
toxProbMat4.CRM1= toxProbMat4.CRM1[complete.cases(toxProbMat4.CRM1), ]

toxProbMat4.CRM2= readRDS(file= "scen4_res_CRM2.rds")$toxProbMat
toxProbMat4.CRM2= toxProbMat4.CRM2[complete.cases(toxProbMat4.CRM2), ]

setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_woPD_3/scen4")
scen= 4
count= 0

lst4.wo= NULL
for(i in idx) {
  count= count+ 1
  lst4.wo[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}


toxProbMat4.wo= getToxProb(lst= lst4.wo, numDoseLevel= 5)
toxProbMat4.wo= toxProbMat4.wo[complete.cases(toxProbMat4.wo), ]

plot_sc4_smdf = reshape2::melt(toxProbMat4)
names(plot_sc4_smdf)= c("sampNum", "dose", "toxProb")
plot_sc4_smdf$design= rep("SDF-wPD", nrow(plot_sc4_smdf))
plot_sc4_smdf$dose= as.factor(plot_sc4_smdf$dose)

plot_sc4_crm1 = reshape2::melt(toxProbMat4.CRM1)
names(plot_sc4_crm1)= c("sampNum", "dose", "toxProb")
plot_sc4_crm1$design= rep("CRM1", nrow(plot_sc4_crm1))
plot_sc4_crm1$dose= as.factor(plot_sc4_crm1$dose)

plot_sc4_crm2 = reshape2::melt(toxProbMat4.CRM2)
names(plot_sc4_crm2)= c("sampNum", "dose", "toxProb")
plot_sc4_crm2$design= rep("CRM2", nrow(plot_sc4_crm2))
plot_sc4_crm2$dose= as.factor(plot_sc4_crm2$dose)

plot_sc4_smdfwo = reshape2::melt(toxProbMat4.wo)
names(plot_sc4_smdfwo)= c("sampNum", "dose", "toxProb")
plot_sc4_smdfwo$design= rep("SDF-woPD", nrow(plot_sc4_smdfwo))
plot_sc4_smdfwo$dose= as.factor(plot_sc4_smdfwo$dose)

plot_sc4_comb= rbind(plot_sc4_smdf, plot_sc4_crm1, plot_sc4_crm2,
                     plot_sc4_smdfwo)
plot_sc4_comb$design= as.factor(plot_sc4_comb$design)


#true_sc4_df= data.frame(dose= 1:5, toxProb= c(0.059, 0.164, 0.292, 0.393, 0.542))
#true_sc4_df= data.frame(dose= 1:5, toxProb= c(0.061, 0.166, 0.293, 0.392, 0.538))
true_sc4_df= data.frame(dose= 1:5, 
                        toxProb= truth.sc4)
d.sc4= data.table(x= true_sc4_df$dose, y=true_sc4_df$toxProb)


p4 <- ggplot() + 
    geom_boxplot(data= plot_sc4_comb, 
                 aes(x=dose, y=toxProb, fill= design))+ 
    labs(title="Post mean of DLT probability for Scenario 4",
         x="dose level", y = "DLT prob.")+ 
    geom_line(data= true_sc4_df,
              aes(x= dose, y= toxProb), linetype= "dashed",
              lwd= 1, col= 2)+
    geom_point(data= d.sc4, aes(x= x, y= y),
               shape= c(2,2,17,2,2), size= 3)
p4



