# Aug 12 2021
# 2-cpt models
# scen 3

# settings for scen 3
#paramLst_pkpop_sc3= list(V= 27, sd_lV= 0.31, 
#                         alpha= 12, sd_lalpha= 0.32,
#                         beta= 0.18, sd_lbeta= 0.33, 
#                         k21= 6.9, sd_lk21= 0.36, 
#                         a= 0.13, a2= 0.1)

paramLst_pkpop_sc3= list(V= 27, sd_lV= 0.27, 
                         alpha= 12, sd_lalpha= 0.23,
                         beta= 0.18, sd_lbeta= 0.22, 
                         k21= 6.9, sd_lk21= 0.24, 
                         a= 0.13, a2= 0.13)




doseInc= c(10, 30, 60, 90, 150)
T0= 1/24

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)


# underlying PD params
betas3.5pl= c(0, 0.106, 8.9, -1.494, 0.501)


# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(27,12,0.18,6.9)), 
                 betas= betas3.5pl, 
                 inte_range= c(0,21))
})
print(true.pi)


S= 2000
nBurnin= 1000
thin= 5
nchain=3

targetProb= 0.3
ksi= 0.9

scenNum= 3
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanwoPD/scen3/traces/"


to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma", "a")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
