# Apr 17 2022
# run trial simulation for aim-2 2-cpt models
# scen 5

library(Rcpp)
library(rstan)

sourceCpp("piMatwoPD0417.cpp")
mod= stan_model("sdfwopd0417.stan")
source("2cpt_woPD_prep.R")

source("scen5_settings.R")


set.seed(1)

for(nSim in 1: 50) {
print(nSim)

    oo2= run_1_trial_2cpt(cohortSize=3, 
                          maxNum= 30,
                          paramLst_pkpop= paramLst_pkpop_sc5, 
                          pd_param_5pl= betas5.5pl,
                          x_timePoints= x.timePoints, 
                          z_timePoints= z.timePoints,
                          inte_range= inte_range, 
                          T0= T0, doseVec= doseInc,
                         
                          S= S, nBurnin= nBurnin, thin= thin, 
                          nchain=nchain,
                          targetProb= targetProb, ksi= ksi, 
                          nSim= nSim, scen= scenNum,
                          path= path1,to_plot=to_plot)
    saveRDS(oo2, file= paste("scen",scenNum, "_res_", nSim,".rds", sep= ''))
}

