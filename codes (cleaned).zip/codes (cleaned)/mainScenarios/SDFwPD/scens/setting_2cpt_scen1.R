# Aug 12 2021
# 2-cpt models
# scen 1

doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas1.5pl= c(0, 0.517, 3.989, -1.930, 0.915) 


# settings for scen 1
paramLst_pkpop_sc1= list(V= 30, sd_lV= 0.21, 
                         alpha= 10, sd_lalpha= 0.20,
                         beta= 0.25, sd_lbeta= 0.19, 
                         k21= 7.1, sd_lk21= 0.19, 
                         a= 0.11, a2= 0.1)

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain= 3

targetProb= 0.3
ksi= 0.9
T0= 1/24

# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(30,10,0.25,7.1)), 
                 betas= betas1.5pl, 
                 inte_range= c(0,21))
})
print(true.pi)

to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma","lambda", "a", "a2")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())


scenNum= 1
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanb/scen1/traces/"
