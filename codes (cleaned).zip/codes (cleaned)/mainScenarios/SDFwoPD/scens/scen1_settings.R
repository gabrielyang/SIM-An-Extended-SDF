# Feb 17 2021, cold in East Texas (blackout)
# the file contains values for hyperparameters, initial values,
# true dose-toxicity profile parameters

# using informative priors for PD parameters
# true param values
V= 30
alpha= 10
beta= 0.25
k21= 7.1
sd_lV= 0.21
sd_lalpha= 0.20
sd_lbeta= 0.19
sd_lk21= 0.19
a= 0.11
a2= 0.1

paramLst_pkpop_sc1= list(V= V, sd_lV= sd_lV, 
                     alpha= alpha, sd_lalpha= sd_lalpha,
                     beta= beta, sd_lbeta= sd_lbeta, 
                     k21= k21, sd_lk21= sd_lk21, a= a, a2= a2)

betas1= c(0, 0.517, 3.989, -1.930, 0.915) 

x_timePoints= c(1,3,6,12,24,48)/24
z_timePoints= c(1.5,3)/24

cohortSize=3
maxNum= 30

inte_range= c(0,21)
T0= 1/24
doseVec= c(10,30,60,90,150)

targetProb= 0.3
ksi= 0.9


true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseVec[x]), 
                 log.psii=log(c(30,10,0.25,7.1)), 
                 betas= betas1, inte_range= inte_range)
})
print(true.pi)


S= 2000
nBurnin= 1000
thin= 5
nchain= 3

scenNum= 1
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanwoPD/scen1/traces/"

to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma", "a")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
