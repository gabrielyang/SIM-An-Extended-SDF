# Aug 12 2021
# 2-cpt models
# scen 2


doseVec= c(10, 30, 60, 90, 150)

# underlying PD params
betas2= c(0, 0.201, 8.795, -1.950, 0.308)

# settings for scen 1
paramLst_pkpop_sc2= list(V= 32, sd_lV= 0.24, 
                         alpha= 11, sd_lalpha= 0.21,
                         beta= 0.15, sd_lbeta= 0.20, 
                         k21= 6, sd_lk21= 0.19, 
                         a= 0.15, a2= 0.13)

#paramLst_pkpop_sc2= list(V= 32, sd_lV= 0.39, 
#                         alpha= 11, sd_lalpha= 0.38,
#                         beta= 0.15, sd_lbeta= 0.38, 
#                         k21= 6, sd_lk21= 0.38, 
#                         a= 0.15, a2= 0.1)


x_timePoints= c(1,3,6,12,24,48)/24
z_timePoints= c(1.5,3)/24
inte_range= c(0,21)

S= 2000
nBurnin= 1000
thin= 5
nchain=3

targetProb= 0.3
ksi= 0.9
T0= 1/24


# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseVec[x]), 
                 log.psii=log(c(32,11,0.15,6)), 
                 betas= betas2, 
                 inte_range= c(0,21))
})
print(true.pi)


scenNum= 2
path1= "/rsrch3/scratch/biostatistics/cyang8/PKPD/aim2RStanwoPD/scen2/traces/"


to_plot= c("Vpop", "alphapop", "betapop","k21pop",
           "sd_lVi", "sd_lalphai","sd_lbetai","sd_lk21i",
           "Emax", "ED50","gamma", "a")


options(buildtools.check = function(action) {T} )
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

