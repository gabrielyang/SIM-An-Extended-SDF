# Aug 19 2021

# load relevant scripts
source("prep_CRM.R")

#timePoints= c(1, 3, 6, 12, 24, 48, 72, 96)

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)
targetProb= 0.3
ksi= 0.9
T0= 1/24


doseVec= c(10,30,60,90,150)
doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas1.5pl= c(0, 0.517, 3.989, -1.930, 0.915) 
betas2.5pl= c(0, 0.201, 8.795, -1.950, 0.308)
betas3.5pl= c(0, 0.106, 8.9, -1.494, 0.501)
betas4.5pl= c(0, 0.632, 9, -0.796, 1.267)
betas5.5pl= c(0.02, 0.335, 8.008, -0.64, 1.3) 

#betas9.5pl= c(0.000,  0.858,  8.988, -0.891,  1.241)


# settings for scen 1
paramLst_pkpop_sc1= list(V= 30, sd_lV= 0.21, 
                         alpha= 10, sd_lalpha= 0.20,
                         beta= 0.25, sd_lbeta= 0.19, 
                         k21= 7.1, sd_lk21= 0.19, 
                         a= 0.11, a2= 0.1)

# 2 prior skeletons for CRM
p0.1 = dfcrm::getprior(halfwidth= 0.05, target= 0.3, 
                       nu=3, nlevel= 5, model="empiric") 
print(p0.1)


p0.2 = dfcrm::getprior(halfwidth= 0.075, target= 0.3, 
                     nu=3, nlevel= 5, model="empiric") 
print(p0.2)


# scen 1
print("scen 1")
# based on data-gen. model
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(30,10,0.25,7.1)), 
                 betas= betas1.5pl, 
                 inte_range= c(0,21))
})

true.pi


# for CRM1
print("CRM1")

set.seed(101)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc1, 
                pd_param_5pl= betas1.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen1","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(107)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc1, 
                pd_param_5pl= betas1.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen1","_res_CRM2",".rds", sep= ''))


# scen 2
print("scen 2")
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(32,11,0.15,6)), 
                 betas= betas2.5pl, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc2= list(V= 32, sd_lV= 0.24, 
                         alpha= 11, sd_lalpha= 0.21,
                         beta= 0.15, sd_lbeta= 0.20, 
                         k21= 6, sd_lk21= 0.19, 
                         a= 0.15, a2= 0.13)


# for CRM1
print("CRM1")

set.seed(10)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc2, 
                pd_param_5pl= betas2.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen2","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(10)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc2, 
                pd_param_5pl= betas2.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen2","_res_CRM2",".rds", sep= ''))


# scen 3
print("scen 3")
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(27,12,0.18,6.9)), 
                 betas= betas3.5pl, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc3= list(V= 27, sd_lV= 0.27, 
                         alpha= 12, sd_lalpha= 0.23,
                         beta= 0.18, sd_lbeta= 0.22, 
                         k21= 6.9, sd_lk21= 0.24, 
                         a= 0.13, a2= 0.13)


# for CRM1
print("CRM1")

set.seed(108)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc3, 
                pd_param_5pl= betas3.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen3","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(114)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc3, 
                pd_param_5pl= betas3.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen3","_res_CRM2",".rds", sep= ''))


# scen 4
print("scen 4")
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(32,12,0.20,7.5)), 
                 betas= betas4.5pl, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc4= list(V= 32, sd_lV= 0.25, 
                         alpha= 12, sd_lalpha= 0.23,
                         beta= 0.20, sd_lbeta= 0.21, 
                         k21= 7.5, sd_lk21= 0.25, 
                         a= 0.14, a2= 0.1)



# for CRM1
print("CRM1")

set.seed(108)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc4, 
                pd_param_5pl= betas4.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt
saveRDS(oo, file= paste("scen4","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(114)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc4, 
                pd_param_5pl= betas4.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt
saveRDS(oo, file= paste("scen4","_res_CRM2",".rds", sep= ''))


# scen 5
print("scen 5")
true.pi= sapply(1:5, function(x) {
    link.2co.5pl(dose= c(T0, doseInc[x]), 
                 log.psii=log(c(33,9.2,0.14,6.3)), 
                 betas= betas5.5pl, 
                 inte_range= c(0,21))
})

true.pi

paramLst_pkpop_sc5= list(V= 33, sd_lV= 0.36, 
                         alpha= 9.2, sd_lalpha= 0.33,
                         beta= 0.14, sd_lbeta= 0.30, 
                         k21= 6.3, sd_lk21= 0.35, 
                         a= 0.20, a2= 0.15)



# for CRM1
print("CRM1")

set.seed(108)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc5, 
                pd_param_5pl= betas5.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

print("CRM2:")

set.seed(114)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc5, 
                pd_param_5pl= betas5.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

##############################################
if(FALSE) {
print("scen 9:")


paramLst_pkpop_sc9= list(V= 32.8, sd_lV= 0.22, 
                         alpha= 12, sd_lalpha= 0.13,
                         beta= 0.2, sd_lbeta= 0.12, 
                         k21= 7.5, sd_lk21= 0.11, 
                         a= 0.2, a2= 0.1)

# for CRM1
print("CRM1")

set.seed(108)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc9, 
                pd_param_5pl= betas9.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.1,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen9","_res_CRM1",".rds", sep= ''))


print("CRM2:")

set.seed(114)
oo= run_crm_sim(paramLst_pkpop= paramLst_pkpop_sc9, 
                pd_param_5pl= betas9.5pl,
                x_timePoints= x.timePoints,
                z_timePoints= z.timePoints,
                T0= T0, 
                cohortSize=3, 
                maxNum= 30, 
                doseVec= doseInc, 
                inte_range= inte_range,
                skeleton= p0.2,
                targetProb= 0.3,
                safetyCutoff= ksi, 
                nSim= 1000)

oo$selProb
oo$allocationNum
oo$toxProb
oo$Npt

saveRDS(oo, file= paste("scen9","_res_CRM2",".rds", sep= ''))
}
