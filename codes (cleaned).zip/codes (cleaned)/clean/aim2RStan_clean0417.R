# Apr 17 2022
# aim 2 table 1
# scripts to get operating characteristics for simulations using RStan sampler


# a func. to calc operating characteristics
calcSummary= function(lst, numDoseLevel= 5) {
    N= length(lst)
    vecc= NULL
    nPts= NULL
    nEvent= NULL
    MTDProb_vec= NULL
    numTrt= rep(0, numDoseLevel)
    
    
    for(i in 1:N) {
        vecc[i]= lst[[i]]$MTD
        numTrt= numTrt+ lst[[i]]$res
        nPts[i]= lst[[i]]$nPts
        nEvent[i]= lst[[i]]$nEvent
        MTDProb_vec[i]= lst[[i]]$MTDProb
    }
    
    selProb= table(vecc)/N
    avgNumTrt= numTrt/N
    totNumPts= mean(nPts)
    avgToxProb= sum(nEvent)/sum(nPts)
    
    return(list(selProb= selProb, avgNumTrt= avgNumTrt,
                totNumPts= totNumPts, avgToxProb= avgToxProb,
                MTDProb_vec= MTDProb_vec))
}

# e.g., SDFwPD, scen1
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/wPD_sim1k/scen1")

idx= c(1:1000)
length(idx)

scen= 1
count= 0

lst1= NULL
for(i in idx) {
    count= count+ 1
    lst1[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
}

out1= calcSummary(lst= lst1, numDoseLevel=5)
out1$selProb*100
out1$avgNumTrt
out1$avgToxProb*100
out1$totNumPts
