# Feb 19 2023
# data generating models
# calc. DLT prob. using integrating-out
# for aim 2 project

pk.conc= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  alpha= psi[2]
  beta= psi[3]
  k21= psi[4]
  
  f1= (alpha-k21)/alpha/(alpha- beta)*(1- exp(-alpha*time))+
    (beta-k21)/beta/(beta- alpha)* (1- exp(-beta* time))
  
  f2= (alpha-k21)/alpha/(alpha- beta)*(exp(-alpha*(time-T0))- exp(-alpha*time))+
    (beta-k21)/beta/(beta- alpha)* (exp(-beta*(time- T0))- exp(-beta* time))
  
  x= (time>= 0 & time<= T0)* D/V/T0* f1+ (time > T0)*D/V/T0* f2
  return(x)
}


pk.log.conc= function(time, dose, log.psii) {
  psi= exp(log.psii)
  V= psi[1]
  alpha= psi[2]
  beta= psi[3]
  k21= psi[4]
  
  T0= dose[1]
  D= dose[2]
  
  f1= (alpha-k21)/alpha/(alpha- beta)*(1- exp(-alpha*time))+
    (beta-k21)/beta/(beta- alpha)* (1- exp(-beta* time))
  
  f2= (alpha-k21)/alpha/(alpha- beta)*
    (exp(-alpha*(time-T0))- exp(-alpha*time))+
    (beta-k21)/beta/(beta- alpha)* 
    (exp(-beta*(time- T0))- exp(-beta* time))
  
  x= (time>=0 & time<= T0)* D/V/T0* f1+ (time> T0)*D/V/T0* f2
  return(log(x))
}

integrand.auc= function(x, log.psii, dose) {
  conc= pk.conc(time= x, dose= dose, log.psii= log.psii) 
  return(conc)
}

link.auc= function(dose, log.psii, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  auc= integral(fun= integrand.auc, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii)  
  return(auc)
}

# compute integral numerically
integrand.2co.se= function(x, log.psii, pdParams, dose) {
  Emax= pdParams[1]
  ED50= pdParams[2]
  gamma= pdParams[3]
  conc= pk.conc(time= x, dose= dose, log.psii= log.psii) 
  return(Emax* conc^gamma/(ED50^gamma+ conc^gamma))
}

# sE PD model w/ fixed link function
link.2co.se= function(dose, log.psii, pdParams, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  eta= integral(fun= integrand.2co.se, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii,
                pdParams= pdParams)  
  return(1- exp(- eta) )
}


# functions to simulate data (the 5-PL PD model)
integrand.2co.5pl= function(x, log.psii, betas, dose) {
  beta1= betas[1]
  beta2= betas[2]
  beta3= betas[3]
  beta4= betas[4]
  beta5= betas[5]
  
  conc= pk.conc(time= x, dose= dose, log.psii= log.psii) 
  res= beta1+ (beta2-beta1)/(1+(conc/beta3)^beta4)^beta5
  return(res)
}

# data generation: fixed link function
# plug-in estimator
link.2co.5pl= function(dose, log.psii, betas, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  eta= integral(fun= integrand.2co.5pl, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii,
                betas= betas)  
  return(1- exp(-eta))
}

# get DLT prob of one dose using integrating out
link.2co.5pl.int= function(dose, log.psii, sd.psi,
                           betas, inte_range, B) {
    
    psiMat= cbind(rlnorm(n=B, meanlog=log.psii[1], sdlog= sd.psi[1]),
                  rlnorm(n=B, meanlog=log.psii[2], sdlog= sd.psi[2]),
                  rlnorm(n=B, meanlog=log.psii[3], sdlog= sd.psi[3]),
                  rlnorm(n=B, meanlog=log.psii[4], sdlog= sd.psi[4]) )
    
    piVec= sapply(1: B, function(b) {
        link.2co.5pl(dose=dose, 
                     log.psii= log(psiMat[b,]), 
                     betas= betas, 
                     inte_range=inte_range) 
        } )
    
    return( mean(piVec))
}



T0=1/24
doseInc= c(10, 30, 60, 90, 150)
# underlying PD params
betas1.5pl= c(0, 0.517, 3.989, -1.930, 0.915) 
betas2.5pl= c(0,0.201,8.795,-1.950,0.308)
betas3.5pl= c(0, 0.106, 8.9, -1.494, 0.501)
betas4.5pl= c(0, 0.632, 9, -0.796, 1.267)
betas5.5pl= c(0.02, 0.335, 8.008, -0.64, 1.30)

library(pracma)

#########################################
# using integrating out
#########################################
library(pracma)
# scen 1
betas1.5pl= c(0, 0.517, 3.989, -1.930, 0.915) 

set.seed(21218)
sapply(1:5, function(k) {
  link.2co.5pl.int(dose= c(1/24,doseInc[k]), 
                   log.psii= log(c(30,10,0.25,7.10)), 
                   sd.psi= c(0.21, 0.20, 0.19, 0.19),
                   betas=betas1.5pl, inte_range=c(0,21), B=1000) 
})
# 0.01 0.06 0.18 0.31 0.51
# CV in AUC=38%

# scen 2
betas2.5pl= c(0, 0.201, 8.795, -1.950, 0.308)

set.seed(21205)
sapply(1:5, function(k) {
  link.2co.5pl.int(dose= c(1/24,doseInc[k]), 
                   log.psii= log(c(32,11,0.15,6.0)), 
                   sd.psi= c(0.24, 0.21, 0.20, 0.19),
                   betas=betas2.5pl, inte_range=c(0,21), B=1000) 
})
#  0.16 0.29 0.40 0.48 0.59
# CV in AUC=41%

# scen 3
betas3.5pl= c(0, 0.106, 8.9, -1.494, 0.501)

set.seed(21209)
sapply(1:5, function(k) {
  link.2co.5pl.int(dose= c(1/24,doseInc[k]), 
                   log.psii= log(c(27,12,0.18,6.9)), 
                   sd.psi= c(0.27, 0.23, 0.22, 0.24),
                   betas=betas3.5pl, inte_range=c(0,21), B=1000) 
})
# 0.05 0.10 0.16 0.21 0.29
# CV in AUC=50%

# scen 4
betas4.5pl= c(0, 0.632, 9, -0.796, 1.267)

set.seed(21205)
sapply(1:5, function(k) {
  link.2co.5pl.int(dose= c(1/24,doseInc[k]), 
                   log.psii= log(c(32,12,0.2,7.5)), 
                   sd.psi= c(0.25, 0.23, 0.21, 0.25),
                   betas=betas4.5pl, inte_range=c(0,21), B=1000) 
})
# 0.07 0.18 0.30 0.40 0.54
# CV in AUC=52%

# scen 5
betas5.5pl= c(0.02, 0.335, 8.008, -0.64, 1.3) 

set.seed(21207)
sapply(1:5, function(k) {
  link.2co.5pl.int(dose= c(1/24,doseInc[k]), 
                   log.psii= log(c(33,9.2,0.14,6.3)), 
                   sd.psi= c(0.36, 0.33, 0.30, 0.35),
                   betas=betas5.5pl, inte_range=c(0,21), B=1000) 
})
# 0.42 0.50 0.57 0.62 0.70

# Mar 13 2023
################################################################
# CV in PK (AUC)
V= rlnorm(n=2e3, meanlog= log(33), sdlog= 0.36)
alpha= rlnorm(n=2e3, meanlog= log(9.2), sdlog= 0.33)
beta= rlnorm(n=2e3, meanlog= log(0.14), sdlog= 0.3)
k21= rlnorm(n=2e3, meanlog= log(6.3), sdlog= 0.35)

AUC= sapply(1:2000, function(k) {
  link.auc(dose= c(1/24, 120), 
           log.psii=log(c(V[k],alpha[k],beta[k],k21[k])), 
  inte_range=c(0,21)) 
})

sd(AUC)/mean(AUC)


AUC= sapply(1:2000, function(k) {
  link.2co.5pl(dose= c(1/24, 10), 
               log.psii=log(c(V[k],alpha[k],beta[k],k21[k])), 
               betas= betas1.5pl, 
             inte_range= c(0,21))})

sd(AUC)/mean(AUC)

#####################
# 1-cpt model
##########################################3
pkConc.1cpt= function(time, dose, log.psii) {
  T0= dose[1]
  D= dose[2]
  psi= exp(log.psii)
  V= psi[1]
  k= psi[2]
  
  res1= D/T0*1/k/V* (1- exp(-k*time))* I(time<= T0)
  res2= D/T0/k/V*(exp(-k*(time-T0))- exp(-k*time))* I(time>T0)
  return(res1+ res2)
}


link.auc.1co= function(dose, log.psii, inte_range) {
  t.begin= inte_range[1]
  t.ref= inte_range[2]
  
  auc= integral(fun= pkConc.1cpt, 
                xmin=t.begin, xmax=t.ref,
                dose= dose, log.psii= log.psii)  
  return(auc)
}


V= rlnorm(n=2e3, meanlog= log(28), sdlog= 0.32)
k= rlnorm(n=2e3, meanlog= log(0.82), sdlog= 0.32)

AUC= sapply(1:2000, function(b) {
  link.auc.1co(dose= c(1/24,120), 
                log.psii=log(c(V[b],k[b])), 
                inte_range=c(0,21)) 
})

sd(AUC)/mean(AUC)


