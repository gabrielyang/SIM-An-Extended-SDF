# May 2 2023
# run simulations for BOIN design

source("prep_BOIN.R")


#timePoints= c(1, 3, 6, 12, 24, 48, 72, 96)

x.timePoints= c(1,3,6,12,24,48)/24
z.timePoints= c(1.5,3)/24
inte_range= c(0,21)
targetProb= 0.3
ksi= 0.9
T0= 1/24


doseVec= c(10,30,60,90,150)
doseInc= c(10, 30, 60, 90, 150)

# underlying PD params
betas6.5pl= c(0.003, 0.76, 2.62, -1.80, 1.19) 
betas7.5pl= c(0.003, 0.934, 1.61, -1.45, 1.59)


# settings for scen 6
paramLst_pkpop_sc6= list(V= 29.3, sd_lV= 0.33, 
                         k21= 0.97, sd_lk21= 0.34, 
                         a= 0.15, a2= 0.13)


# scen 6
print("scen 6")
true.pi= sapply(1:5, function(x) {
  link.1co.5pl(dose= c(T0, doseInc[x]), 
               log.psii=log(c(29.3,0.97)), 
               betas= betas6.5pl, 
               inte_range= c(0,21))
})

true.pi

set.seed(515)
oo2= run_BOIN_sim(cohortSize=3, 
                  maxNum= 30,
                  paramLst_pkpop= paramLst_pkpop_sc6, 
                  pd_param_5pl= betas6.5pl,
                  x_timePoints= x.timePoints,
                  z_timePoints= z.timePoints,
                  inte_range= inte_range, 
                  T0= T0, doseVec= doseVec,
                  targetProb=0.3,  
                  n.earlystop = 100, startdose = 1, 
                  p.saf= NULL, p.tox = NULL, 
                  cutoff.eli = 0.95, extrasafe = FALSE, 
                  offset= 0.05, nSim= 1000)
oo2$selProb
oo2$avgPtsAllo
oo2$avgtotalPts
oo2$avgToxProb


# scen 7
print("scen 7")
true.pi= sapply(1:5, function(x) {
  link.1co.5pl(dose= c(T0, doseInc[x]), 
               log.psii=log(c(30.2, 0.98)), 
               betas= betas7.5pl, 
               inte_range= c(0,21))
})

true.pi


paramLst_pkpop_sc7= list(V= 30.2, sd_lV= 0.33, 
                         k21= 0.98, sd_lk21= 0.32, 
                         a= 0.13, a2= 0.14)

set.seed(337)
oo2= run_BOIN_sim(cohortSize=3, 
                  maxNum= 30,
                  paramLst_pkpop= paramLst_pkpop_sc7, 
                  pd_param_5pl= betas7.5pl,
                  x_timePoints= x.timePoints,
                  z_timePoints= z.timePoints,
                  inte_range= inte_range, 
                  T0= T0, doseVec= doseVec,
                  targetProb=0.3,  
                  n.earlystop = 100, startdose = 1, 
                  p.saf= NULL, p.tox = NULL, 
                  cutoff.eli = 0.95, extrasafe = FALSE, 
                  offset= 0.05, nSim= 1000)
oo2$selProb
oo2$avgPtsAllo
oo2$avgtotalPts
oo2$avgToxProb

