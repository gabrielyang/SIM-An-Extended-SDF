# May 22 2022
# Aim 2, for SDF-wPD and CRM designs (the model based designs)

# a function to calculate average credible interval length and coverage prob
# for DLT prob at MTD and its nearby doses
calcCILength= function(piMatLst, truth) {
    nDose= length(truth)
    S= length(piMatLst)
    
    indMat= matrix(NA, nrow= S, ncol= nDose)
    lengthMat= matrix(NA, nrow= S, ncol= nDose)

    for(s in 1:S) {
        tempMat= sapply(1:nDose, function(k) {
            quantile(piMatLst[[s]][,k], c(0.025, 0.975))
        })
        
        indMat[s,]= sapply(1:nDose, function(k) {
            I(tempMat[1,k]< truth[k] &  truth[k]< tempMat[2,k] )
        })
        
        lengthMat[s,]= sapply(1:nDose, function(k) {
            tempMat[2,k]-  tempMat[1,k]
        })
    }
    return(list(indMat= indMat, lengthMat= lengthMat))
    
}

# the data list contains the summary quantiles of DLT prob at each dose
calcCILength.CRM= function(quantpiMatLst, truth) {
    nDose= length(truth)
    S= length(quantpiMatLst)
    
    indMat= matrix(NA, nrow= S, ncol= nDose)
    lengthMat= matrix(NA, nrow= S, ncol= nDose)
    
    for(s in 1:S) {
        tempMat= quantpiMatLst[[s]]
        
        indMat[s,]= sapply(1:nDose, function(k) {
            I(tempMat[1,k]< truth[k] & tempMat[2,k]> truth[k])
        })
        
        lengthMat[s,]= sapply(1:nDose, function(k) {
            tempMat[2,k]-  tempMat[1,k]
        })
    }
    return(list(indMat= indMat, lengthMat= lengthMat))
    
}


truth.sc1= c(0.010, 0.063, 0.178, 0.306, 0.510)
truth.sc2= c(0.165, 0.292, 0.404, 0.483, 0.591)
truth.sc3= c(0.047,0.101, 0.163, 0.210, 0.291)
truth.sc4= c(0.066, 0.176, 0.301, 0.399, 0.543)


##################################################
# the SDF-wPD design
##################################################

# scen1
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen1")

idx= c(1:1000)
length(idx)

scen= 1
count= 0

lst1= NULL
piMatLst1= NULL

for(i in idx) {
    count= count+ 1
    lst1[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
    piMatLst1[[count]]= lst1[[count]]$piMat
}

#load(file= "aim2_sdf_res_sc1.RData")

aa1= calcCILength(piMatLst= piMatLst1, truth= truth.sc1)
colMeans(aa1$indMat)[3:5]
colMeans(aa1$lengthMat)[3:5]


# scen2
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen2")

idx= c(1:1000)
length(idx)

scen= 2
count= 0

lst2= NULL
piMatLst2= NULL

for(i in idx) {
    count= count+ 1
    lst2[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
    piMatLst2[[count]]= lst2[[count]]$piMat
}

aa2= calcCILength(piMatLst= piMatLst2, truth= truth.sc2)
colMeans(aa2$indMat)[1:3]
colMeans(aa2$lengthMat)[1:3]


# scen3
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen3")

idx= c(1:1000)
length(idx)

scen= 3
count= 0

lst3= NULL
piMatLst3= NULL

for(i in idx) {
    count= count+ 1
    lst3[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
    piMatLst3[[count]]= lst3[[count]]$piMat
}

aa3= calcCILength(piMatLst= piMatLst3, truth= truth.sc3)
colMeans(aa3$indMat)[4:5]
colMeans(aa3$lengthMat)[4:5]


# scen4
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/sim1k_05/scen4")

idx= c(1:1000)
length(idx)

scen= 4
count= 0

lst4= NULL
piMatLst4= NULL

for(i in idx) {
    count= count+ 1
    lst4[[count]]= readRDS(paste("scen",scen,"_res_", i, ".rds",sep= ''))
    piMatLst4[[count]]= lst4[[count]]$piMat
}

aa4= calcCILength(piMatLst= piMatLst4, truth= truth.sc4)
colMeans(aa4$indMat)[2:4]
colMeans(aa4$lengthMat)[2:4]


###################################################################
# the CRMs
###################################################################
setwd("C:/Users/cyang8/Reseraches/PKPD2/aim2-RStan/resultDatasets3/CRM")


# scen 1
sc1.piMatLst.crm1= readRDS(file= "scen1_res_CRM1.rds")$DLTProbMatLst

aa1.crm1= calcCILength.CRM(quantpiMatLst= sc1.piMatLst.crm1, 
                           truth= truth.sc1)
colMeans(aa1.crm1$indMat)[3:5]
colMeans(aa1.crm1$lengthMat)[3:5]


sc1.piMatLst.crm2= readRDS(file= "scen1_res_CRM2.rds")$DLTProbMatLst

aa1.crm2= calcCILength.CRM(quantpiMatLst= sc1.piMatLst.crm2, 
                           truth= truth.sc1)
colMeans(aa1.crm2$indMat)[3:5]
colMeans(aa1.crm2$lengthMat)[3:5]

# scen 2
sc2.piMatLst.crm1= readRDS(file= "scen2_res_CRM1.rds")$DLTProbMatLst

aa2.crm1= calcCILength.CRM(quantpiMatLst= sc2.piMatLst.crm1, 
                           truth= truth.sc2)
colMeans(aa2.crm1$indMat)[1:3]
colMeans(aa2.crm1$lengthMat)[1:3]


sc2.piMatLst.crm2= readRDS(file= "scen2_res_CRM2.rds")$DLTProbMatLst

aa2.crm2= calcCILength.CRM(quantpiMatLst= sc2.piMatLst.crm2, 
                           truth= truth.sc2)
colMeans(aa2.crm2$indMat)[1:3]
colMeans(aa2.crm2$lengthMat)[1:3]

# scen 3
sc3.piMatLst.crm1= readRDS(file= "scen3_res_CRM1.rds")$DLTProbMatLst

aa3.crm1= calcCILength.CRM(quantpiMatLst= sc3.piMatLst.crm1, 
                           truth= truth.sc3)
colMeans(aa3.crm1$indMat)[4:5]
colMeans(aa3.crm1$lengthMat)[4:5]


sc3.piMatLst.crm2= readRDS(file= "scen3_res_CRM2.rds")$DLTProbMatLst

aa3.crm2= calcCILength.CRM(quantpiMatLst= sc3.piMatLst.crm2, 
                           truth= truth.sc3)
colMeans(aa3.crm2$indMat)[4:5]
colMeans(aa3.crm2$lengthMat)[4:5]

# scen 4
sc4.piMatLst.crm1= readRDS(file= "scen4_res_CRM1.rds")$DLTProbMatLst

aa4.crm1= calcCILength.CRM(quantpiMatLst= sc4.piMatLst.crm1, 
                           truth= truth.sc4)
colMeans(aa4.crm1$indMat)[2:4]
colMeans(aa4.crm1$lengthMat)[2:4]


sc4.piMatLst.crm2= readRDS(file= "scen4_res_CRM2.rds")$DLTProbMatLst

aa4.crm2= calcCILength.CRM(quantpiMatLst= sc4.piMatLst.crm2, 
                           truth= truth.sc4)
colMeans(aa4.crm2$indMat)[2:4]
colMeans(aa4.crm2$lengthMat)[2:4]

